<?php

/* FMCoreBundle:Default:index.html.twig */
class __TwigTemplate_0b5efd0ad016d7673e8dbd4702be019e8a88d4d0b2da463c71a0b0fb8c45a1c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<html>
  <body>
    Hello World!
  </body>
</html>";
    }

    public function getTemplateName()
    {
        return "FMCoreBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "FMCoreBundle:Default:index.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\src\\FM\\CoreBundle/Resources/views/Default/index.html.twig");
    }
}
