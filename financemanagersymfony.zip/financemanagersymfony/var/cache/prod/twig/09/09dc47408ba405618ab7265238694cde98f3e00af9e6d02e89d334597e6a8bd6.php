<?php

/* FMCoreBundle:Default:index.html.twig */
class __TwigTemplate_fffd97019650f2e4665d2bc59e7a2528dcd02f3562d6dceedc94f13c47a14103 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f13bb2808359d8834c24551ca2c855ef14cec8c4b283d825aa76928562a15a05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f13bb2808359d8834c24551ca2c855ef14cec8c4b283d825aa76928562a15a05->enter($__internal_f13bb2808359d8834c24551ca2c855ef14cec8c4b283d825aa76928562a15a05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FMCoreBundle:Default:index.html.twig"));

        // line 2
        echo "
<html>
  <body>
    Hello World!
  </body>
</html>";
        
        $__internal_f13bb2808359d8834c24551ca2c855ef14cec8c4b283d825aa76928562a15a05->leave($__internal_f13bb2808359d8834c24551ca2c855ef14cec8c4b283d825aa76928562a15a05_prof);

    }

    public function getTemplateName()
    {
        return "FMCoreBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/Default/index.html.twig #}

<html>
  <body>
    Hello World!
  </body>
</html>", "FMCoreBundle:Default:index.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\src\\FM\\CoreBundle\\Resources\\views\\Default\\index.html.twig");
    }
}
