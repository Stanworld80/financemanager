<?php

/* @FMCore/Default/index.html.twig */
class __TwigTemplate_3b06c7a2d6112348ecd6fc412f6de231a1b3d1451ed3c7972252fb6b8e6fe475 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<html>
  <body>
    Hello World!
  </body>
</html>";
    }

    public function getTemplateName()
    {
        return "@FMCore/Default/index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@FMCore/Default/index.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\src\\FM\\CoreBundle\\Resources\\views\\Default\\index.html.twig");
    }
}
