<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_8662065b47d86599fa1bbb5cd25eeaa3d6f500252b25ece02d39b0f40ad5d700 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1cb8ff0fca037fa528e91a53dd18418dbad8e0f6a376f7965aa7bb1c47f1689 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1cb8ff0fca037fa528e91a53dd18418dbad8e0f6a376f7965aa7bb1c47f1689->enter($__internal_f1cb8ff0fca037fa528e91a53dd18418dbad8e0f6a376f7965aa7bb1c47f1689_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_a019aca77728fc3632ec790a6ca855a7546e14b1b5652b8f1aeab04fbc3dea1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a019aca77728fc3632ec790a6ca855a7546e14b1b5652b8f1aeab04fbc3dea1c->enter($__internal_a019aca77728fc3632ec790a6ca855a7546e14b1b5652b8f1aeab04fbc3dea1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_f1cb8ff0fca037fa528e91a53dd18418dbad8e0f6a376f7965aa7bb1c47f1689->leave($__internal_f1cb8ff0fca037fa528e91a53dd18418dbad8e0f6a376f7965aa7bb1c47f1689_prof);

        
        $__internal_a019aca77728fc3632ec790a6ca855a7546e14b1b5652b8f1aeab04fbc3dea1c->leave($__internal_a019aca77728fc3632ec790a6ca855a7546e14b1b5652b8f1aeab04fbc3dea1c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
