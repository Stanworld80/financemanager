<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_b4917099ad595ef29c5fb2e3ae42e3c47ff931bacceb4ea3f9ba1bf60a57196a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_70d3d73e2c84203f3c1db6cb00fbdd482304f34a5089bab73f0f805b231ef228 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70d3d73e2c84203f3c1db6cb00fbdd482304f34a5089bab73f0f805b231ef228->enter($__internal_70d3d73e2c84203f3c1db6cb00fbdd482304f34a5089bab73f0f805b231ef228_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $__internal_2d1ea0fdd534e7599b05b31786910b273806234a627533b5a8e58f85e96c091e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d1ea0fdd534e7599b05b31786910b273806234a627533b5a8e58f85e96c091e->enter($__internal_2d1ea0fdd534e7599b05b31786910b273806234a627533b5a8e58f85e96c091e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_70d3d73e2c84203f3c1db6cb00fbdd482304f34a5089bab73f0f805b231ef228->leave($__internal_70d3d73e2c84203f3c1db6cb00fbdd482304f34a5089bab73f0f805b231ef228_prof);

        
        $__internal_2d1ea0fdd534e7599b05b31786910b273806234a627533b5a8e58f85e96c091e->leave($__internal_2d1ea0fdd534e7599b05b31786910b273806234a627533b5a8e58f85e96c091e_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_34a807574f1d4c83d7e7d458c29994aa6d6ef86315aaa7afb4135519c8f3f249 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34a807574f1d4c83d7e7d458c29994aa6d6ef86315aaa7afb4135519c8f3f249->enter($__internal_34a807574f1d4c83d7e7d458c29994aa6d6ef86315aaa7afb4135519c8f3f249_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_d00614fb72be667ac67504129dbdf2965b7eed2ffdf017ebf64421788cf8ee3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d00614fb72be667ac67504129dbdf2965b7eed2ffdf017ebf64421788cf8ee3c->enter($__internal_d00614fb72be667ac67504129dbdf2965b7eed2ffdf017ebf64421788cf8ee3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_d00614fb72be667ac67504129dbdf2965b7eed2ffdf017ebf64421788cf8ee3c->leave($__internal_d00614fb72be667ac67504129dbdf2965b7eed2ffdf017ebf64421788cf8ee3c_prof);

        
        $__internal_34a807574f1d4c83d7e7d458c29994aa6d6ef86315aaa7afb4135519c8f3f249->leave($__internal_34a807574f1d4c83d7e7d458c29994aa6d6ef86315aaa7afb4135519c8f3f249_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_aeb570bac11ea1f7b098017d4a389a367bcdc2e5495d5cfc457d57b537d42c65 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aeb570bac11ea1f7b098017d4a389a367bcdc2e5495d5cfc457d57b537d42c65->enter($__internal_aeb570bac11ea1f7b098017d4a389a367bcdc2e5495d5cfc457d57b537d42c65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_3e23846e5da8f39190194fcf97601177f394c213d9f7abbf2cb8893e5071d7c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e23846e5da8f39190194fcf97601177f394c213d9f7abbf2cb8893e5071d7c1->enter($__internal_3e23846e5da8f39190194fcf97601177f394c213d9f7abbf2cb8893e5071d7c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_3e23846e5da8f39190194fcf97601177f394c213d9f7abbf2cb8893e5071d7c1->leave($__internal_3e23846e5da8f39190194fcf97601177f394c213d9f7abbf2cb8893e5071d7c1_prof);

        
        $__internal_aeb570bac11ea1f7b098017d4a389a367bcdc2e5495d5cfc457d57b537d42c65->leave($__internal_aeb570bac11ea1f7b098017d4a389a367bcdc2e5495d5cfc457d57b537d42c65_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_4de4d357525ea11a20f3bd4dbe444f680c4c8b30d2040eaf9b40864c7becf960 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4de4d357525ea11a20f3bd4dbe444f680c4c8b30d2040eaf9b40864c7becf960->enter($__internal_4de4d357525ea11a20f3bd4dbe444f680c4c8b30d2040eaf9b40864c7becf960_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ed5f33654f284719ff9a788f6f2f287c7be87c1d05f5237dd04b6e4adba53c82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed5f33654f284719ff9a788f6f2f287c7be87c1d05f5237dd04b6e4adba53c82->enter($__internal_ed5f33654f284719ff9a788f6f2f287c7be87c1d05f5237dd04b6e4adba53c82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 141)->display($context);
        
        $__internal_ed5f33654f284719ff9a788f6f2f287c7be87c1d05f5237dd04b6e4adba53c82->leave($__internal_ed5f33654f284719ff9a788f6f2f287c7be87c1d05f5237dd04b6e4adba53c82_prof);

        
        $__internal_4de4d357525ea11a20f3bd4dbe444f680c4c8b30d2040eaf9b40864c7becf960->leave($__internal_4de4d357525ea11a20f3bd4dbe444f680c4c8b30d2040eaf9b40864c7becf960_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "TwigBundle:Exception:exception_full.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
