<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_160ddd6e734ee41808f5f77e31bfadf5e7bb8e7368aa83d79f46aae3edb828fb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b04bad738ad6f4fa84a24cffb7d05dec7a848ae07edccd224f8c8333ccab2295 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b04bad738ad6f4fa84a24cffb7d05dec7a848ae07edccd224f8c8333ccab2295->enter($__internal_b04bad738ad6f4fa84a24cffb7d05dec7a848ae07edccd224f8c8333ccab2295_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_6b3b24fd3fbd7ee5a8052ec27f2a60cc903244467fcf0c36c1adad04fd54d0cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b3b24fd3fbd7ee5a8052ec27f2a60cc903244467fcf0c36c1adad04fd54d0cb->enter($__internal_6b3b24fd3fbd7ee5a8052ec27f2a60cc903244467fcf0c36c1adad04fd54d0cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b04bad738ad6f4fa84a24cffb7d05dec7a848ae07edccd224f8c8333ccab2295->leave($__internal_b04bad738ad6f4fa84a24cffb7d05dec7a848ae07edccd224f8c8333ccab2295_prof);

        
        $__internal_6b3b24fd3fbd7ee5a8052ec27f2a60cc903244467fcf0c36c1adad04fd54d0cb->leave($__internal_6b3b24fd3fbd7ee5a8052ec27f2a60cc903244467fcf0c36c1adad04fd54d0cb_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_175368ad5c78cec4c35f231970fd616b59f14172ee2cb5e465dcd63553d87280 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_175368ad5c78cec4c35f231970fd616b59f14172ee2cb5e465dcd63553d87280->enter($__internal_175368ad5c78cec4c35f231970fd616b59f14172ee2cb5e465dcd63553d87280_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_c72b9a96d8041bd399e98d8df55e3fafa06f5fb9d0a48f90450aac780fc78797 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c72b9a96d8041bd399e98d8df55e3fafa06f5fb9d0a48f90450aac780fc78797->enter($__internal_c72b9a96d8041bd399e98d8df55e3fafa06f5fb9d0a48f90450aac780fc78797_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_c72b9a96d8041bd399e98d8df55e3fafa06f5fb9d0a48f90450aac780fc78797->leave($__internal_c72b9a96d8041bd399e98d8df55e3fafa06f5fb9d0a48f90450aac780fc78797_prof);

        
        $__internal_175368ad5c78cec4c35f231970fd616b59f14172ee2cb5e465dcd63553d87280->leave($__internal_175368ad5c78cec4c35f231970fd616b59f14172ee2cb5e465dcd63553d87280_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_e6f759b921a7cc72238c442fe5b68f16813b067d226c7233e77aa722349f7bbe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6f759b921a7cc72238c442fe5b68f16813b067d226c7233e77aa722349f7bbe->enter($__internal_e6f759b921a7cc72238c442fe5b68f16813b067d226c7233e77aa722349f7bbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_aed34f70dba609c77901b61ff9209a36871e7d2a06325eddc1ad77e14e33c6e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aed34f70dba609c77901b61ff9209a36871e7d2a06325eddc1ad77e14e33c6e0->enter($__internal_aed34f70dba609c77901b61ff9209a36871e7d2a06325eddc1ad77e14e33c6e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_aed34f70dba609c77901b61ff9209a36871e7d2a06325eddc1ad77e14e33c6e0->leave($__internal_aed34f70dba609c77901b61ff9209a36871e7d2a06325eddc1ad77e14e33c6e0_prof);

        
        $__internal_e6f759b921a7cc72238c442fe5b68f16813b067d226c7233e77aa722349f7bbe->leave($__internal_e6f759b921a7cc72238c442fe5b68f16813b067d226c7233e77aa722349f7bbe_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
