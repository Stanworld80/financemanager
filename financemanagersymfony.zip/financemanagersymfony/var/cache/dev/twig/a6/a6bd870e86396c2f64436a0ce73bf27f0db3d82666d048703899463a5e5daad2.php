<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_e880b5cd020890817ddd9a392ba8681e5d2cf6798d15f975e0ee63a394d72a23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb5f6faf3c98bdb1d9a3cc1d364cb17c431937ee4cd8dfdcbd0c7701b3a846e6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb5f6faf3c98bdb1d9a3cc1d364cb17c431937ee4cd8dfdcbd0c7701b3a846e6->enter($__internal_eb5f6faf3c98bdb1d9a3cc1d364cb17c431937ee4cd8dfdcbd0c7701b3a846e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_9b14a29a5bfb6fa9c0b49448537f7c359f410ddc43ff98e1551f7111e64be663 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b14a29a5bfb6fa9c0b49448537f7c359f410ddc43ff98e1551f7111e64be663->enter($__internal_9b14a29a5bfb6fa9c0b49448537f7c359f410ddc43ff98e1551f7111e64be663_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_eb5f6faf3c98bdb1d9a3cc1d364cb17c431937ee4cd8dfdcbd0c7701b3a846e6->leave($__internal_eb5f6faf3c98bdb1d9a3cc1d364cb17c431937ee4cd8dfdcbd0c7701b3a846e6_prof);

        
        $__internal_9b14a29a5bfb6fa9c0b49448537f7c359f410ddc43ff98e1551f7111e64be663->leave($__internal_9b14a29a5bfb6fa9c0b49448537f7c359f410ddc43ff98e1551f7111e64be663_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
