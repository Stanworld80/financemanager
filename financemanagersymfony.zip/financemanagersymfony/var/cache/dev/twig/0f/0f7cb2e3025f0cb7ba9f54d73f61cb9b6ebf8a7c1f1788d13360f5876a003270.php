<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_c226424450d01cd958170363524947f923f26a79ad5d4dc2ca407dba618e5e5f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aca201c88e095b755d9a447e6687d085c5d36d76b8e58c235ef219a4c5ccd0d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aca201c88e095b755d9a447e6687d085c5d36d76b8e58c235ef219a4c5ccd0d5->enter($__internal_aca201c88e095b755d9a447e6687d085c5d36d76b8e58c235ef219a4c5ccd0d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_3970c3946ac99d6c4fa69fa6c05bbdbec8c31c3a6b14eb2c5767eb30fa79c867 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3970c3946ac99d6c4fa69fa6c05bbdbec8c31c3a6b14eb2c5767eb30fa79c867->enter($__internal_3970c3946ac99d6c4fa69fa6c05bbdbec8c31c3a6b14eb2c5767eb30fa79c867_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aca201c88e095b755d9a447e6687d085c5d36d76b8e58c235ef219a4c5ccd0d5->leave($__internal_aca201c88e095b755d9a447e6687d085c5d36d76b8e58c235ef219a4c5ccd0d5_prof);

        
        $__internal_3970c3946ac99d6c4fa69fa6c05bbdbec8c31c3a6b14eb2c5767eb30fa79c867->leave($__internal_3970c3946ac99d6c4fa69fa6c05bbdbec8c31c3a6b14eb2c5767eb30fa79c867_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_88f80f066943f90fcf39cf0604557c77cd3f846e1d16f9d0dcce1252c0035685 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88f80f066943f90fcf39cf0604557c77cd3f846e1d16f9d0dcce1252c0035685->enter($__internal_88f80f066943f90fcf39cf0604557c77cd3f846e1d16f9d0dcce1252c0035685_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0b0f384eac9688ef4e8471d5090c47b55912fdf810befc2d9531fee77451356e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b0f384eac9688ef4e8471d5090c47b55912fdf810befc2d9531fee77451356e->enter($__internal_0b0f384eac9688ef4e8471d5090c47b55912fdf810befc2d9531fee77451356e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_0b0f384eac9688ef4e8471d5090c47b55912fdf810befc2d9531fee77451356e->leave($__internal_0b0f384eac9688ef4e8471d5090c47b55912fdf810befc2d9531fee77451356e_prof);

        
        $__internal_88f80f066943f90fcf39cf0604557c77cd3f846e1d16f9d0dcce1252c0035685->leave($__internal_88f80f066943f90fcf39cf0604557c77cd3f846e1d16f9d0dcce1252c0035685_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_4c4e35d5ec2d4e84a58d340712eeb6cb63e1d08eaccdee91fbf8c4b1ed7fe334 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c4e35d5ec2d4e84a58d340712eeb6cb63e1d08eaccdee91fbf8c4b1ed7fe334->enter($__internal_4c4e35d5ec2d4e84a58d340712eeb6cb63e1d08eaccdee91fbf8c4b1ed7fe334_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d50ce658232399be21fa14da79d898d52677ac9c96aa057900ec05062264992c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d50ce658232399be21fa14da79d898d52677ac9c96aa057900ec05062264992c->enter($__internal_d50ce658232399be21fa14da79d898d52677ac9c96aa057900ec05062264992c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_d50ce658232399be21fa14da79d898d52677ac9c96aa057900ec05062264992c->leave($__internal_d50ce658232399be21fa14da79d898d52677ac9c96aa057900ec05062264992c_prof);

        
        $__internal_4c4e35d5ec2d4e84a58d340712eeb6cb63e1d08eaccdee91fbf8c4b1ed7fe334->leave($__internal_4c4e35d5ec2d4e84a58d340712eeb6cb63e1d08eaccdee91fbf8c4b1ed7fe334_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
