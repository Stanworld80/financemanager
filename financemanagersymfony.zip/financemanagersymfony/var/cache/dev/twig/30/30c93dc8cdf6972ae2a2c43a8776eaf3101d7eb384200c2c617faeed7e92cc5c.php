<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_4636f147e5f61754611d1e3378dfab98d1aae296d339b07bbe1163ced9283ca8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae14e5a19f2523e8f2414e8bf20600765ab89571bbe1d2debb47b8323e79125e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae14e5a19f2523e8f2414e8bf20600765ab89571bbe1d2debb47b8323e79125e->enter($__internal_ae14e5a19f2523e8f2414e8bf20600765ab89571bbe1d2debb47b8323e79125e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_fa6b30cc464f671f6b65681650e36f9f9b8ce6b05046f5fd08076e137c3cee9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa6b30cc464f671f6b65681650e36f9f9b8ce6b05046f5fd08076e137c3cee9c->enter($__internal_fa6b30cc464f671f6b65681650e36f9f9b8ce6b05046f5fd08076e137c3cee9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_ae14e5a19f2523e8f2414e8bf20600765ab89571bbe1d2debb47b8323e79125e->leave($__internal_ae14e5a19f2523e8f2414e8bf20600765ab89571bbe1d2debb47b8323e79125e_prof);

        
        $__internal_fa6b30cc464f671f6b65681650e36f9f9b8ce6b05046f5fd08076e137c3cee9c->leave($__internal_fa6b30cc464f671f6b65681650e36f9f9b8ce6b05046f5fd08076e137c3cee9c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
