<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_0a05875b8dcd1905ced758d797c16d5bd35942831022184846e48226124ee1f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5964fb220733b1d7b719430256181ab3138b4415c518968dd0b9bb59bae271fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5964fb220733b1d7b719430256181ab3138b4415c518968dd0b9bb59bae271fa->enter($__internal_5964fb220733b1d7b719430256181ab3138b4415c518968dd0b9bb59bae271fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_a85f9a0e756cff5dffa5a9f399229c9375a655a95b3edca2b3422330a92ede85 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a85f9a0e756cff5dffa5a9f399229c9375a655a95b3edca2b3422330a92ede85->enter($__internal_a85f9a0e756cff5dffa5a9f399229c9375a655a95b3edca2b3422330a92ede85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_5964fb220733b1d7b719430256181ab3138b4415c518968dd0b9bb59bae271fa->leave($__internal_5964fb220733b1d7b719430256181ab3138b4415c518968dd0b9bb59bae271fa_prof);

        
        $__internal_a85f9a0e756cff5dffa5a9f399229c9375a655a95b3edca2b3422330a92ede85->leave($__internal_a85f9a0e756cff5dffa5a9f399229c9375a655a95b3edca2b3422330a92ede85_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form.html.php");
    }
}
