<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_b549632acf015d162fb61593e0530139ac2730a4642372bdb7d60c6e3d7cbb7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1cd28624d663ff73203a55df90b0b78cbf6daa24870176ab32e382e1fd946dd2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cd28624d663ff73203a55df90b0b78cbf6daa24870176ab32e382e1fd946dd2->enter($__internal_1cd28624d663ff73203a55df90b0b78cbf6daa24870176ab32e382e1fd946dd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_3c09343ab2ec71d3c8af6af78677d2737559836e184fe79c8f19b97df348947c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c09343ab2ec71d3c8af6af78677d2737559836e184fe79c8f19b97df348947c->enter($__internal_3c09343ab2ec71d3c8af6af78677d2737559836e184fe79c8f19b97df348947c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_1cd28624d663ff73203a55df90b0b78cbf6daa24870176ab32e382e1fd946dd2->leave($__internal_1cd28624d663ff73203a55df90b0b78cbf6daa24870176ab32e382e1fd946dd2_prof);

        
        $__internal_3c09343ab2ec71d3c8af6af78677d2737559836e184fe79c8f19b97df348947c->leave($__internal_3c09343ab2ec71d3c8af6af78677d2737559836e184fe79c8f19b97df348947c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
