<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_450fe5e6df89492527aea074cde423f98d3cbc779be0c3dd15a22c18ceee0832 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7405ccf6340bd0087c48f53b99acc911b524b37cfaa1f8a3450a8ec722b38845 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7405ccf6340bd0087c48f53b99acc911b524b37cfaa1f8a3450a8ec722b38845->enter($__internal_7405ccf6340bd0087c48f53b99acc911b524b37cfaa1f8a3450a8ec722b38845_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_b7d172dec2a2d3cba223d2fab72e5857c2c6cee9fc9fdd9a946c10c9cc71a979 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7d172dec2a2d3cba223d2fab72e5857c2c6cee9fc9fdd9a946c10c9cc71a979->enter($__internal_b7d172dec2a2d3cba223d2fab72e5857c2c6cee9fc9fdd9a946c10c9cc71a979_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_7405ccf6340bd0087c48f53b99acc911b524b37cfaa1f8a3450a8ec722b38845->leave($__internal_7405ccf6340bd0087c48f53b99acc911b524b37cfaa1f8a3450a8ec722b38845_prof);

        
        $__internal_b7d172dec2a2d3cba223d2fab72e5857c2c6cee9fc9fdd9a946c10c9cc71a979->leave($__internal_b7d172dec2a2d3cba223d2fab72e5857c2c6cee9fc9fdd9a946c10c9cc71a979_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
