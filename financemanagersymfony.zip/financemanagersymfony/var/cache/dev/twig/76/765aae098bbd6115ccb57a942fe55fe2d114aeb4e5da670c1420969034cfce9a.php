<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_932f19e9621faee0531c159e8cb699006563d530eb694cec1ca0623b275bf2ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f45bbafa37b98069cefb031053006a4a8ee0a14468e048c31c4d5be5c0f8a63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f45bbafa37b98069cefb031053006a4a8ee0a14468e048c31c4d5be5c0f8a63->enter($__internal_7f45bbafa37b98069cefb031053006a4a8ee0a14468e048c31c4d5be5c0f8a63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_f81f34a2b6c35d29b2ff3d3dfadd8f832deea9de3706d9d9dda7e1aa45eb5da2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f81f34a2b6c35d29b2ff3d3dfadd8f832deea9de3706d9d9dda7e1aa45eb5da2->enter($__internal_f81f34a2b6c35d29b2ff3d3dfadd8f832deea9de3706d9d9dda7e1aa45eb5da2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_7f45bbafa37b98069cefb031053006a4a8ee0a14468e048c31c4d5be5c0f8a63->leave($__internal_7f45bbafa37b98069cefb031053006a4a8ee0a14468e048c31c4d5be5c0f8a63_prof);

        
        $__internal_f81f34a2b6c35d29b2ff3d3dfadd8f832deea9de3706d9d9dda7e1aa45eb5da2->leave($__internal_f81f34a2b6c35d29b2ff3d3dfadd8f832deea9de3706d9d9dda7e1aa45eb5da2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
