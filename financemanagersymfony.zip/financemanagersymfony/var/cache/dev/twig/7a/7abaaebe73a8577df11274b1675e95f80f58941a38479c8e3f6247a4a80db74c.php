<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_a80ea09f0d34d33f50c2b8156eca3915629f378eba4d6944cc29d814e2c21153 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a3580faa07732d00daeb4fc23d9c8d101382e159f5ca8ef8c630dbd3e7aba890 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3580faa07732d00daeb4fc23d9c8d101382e159f5ca8ef8c630dbd3e7aba890->enter($__internal_a3580faa07732d00daeb4fc23d9c8d101382e159f5ca8ef8c630dbd3e7aba890_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_c4c385fc2ff36383fe5a29084408c259ca3d1b5e6586ef78cdf8cff0b573c4d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4c385fc2ff36383fe5a29084408c259ca3d1b5e6586ef78cdf8cff0b573c4d4->enter($__internal_c4c385fc2ff36383fe5a29084408c259ca3d1b5e6586ef78cdf8cff0b573c4d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_a3580faa07732d00daeb4fc23d9c8d101382e159f5ca8ef8c630dbd3e7aba890->leave($__internal_a3580faa07732d00daeb4fc23d9c8d101382e159f5ca8ef8c630dbd3e7aba890_prof);

        
        $__internal_c4c385fc2ff36383fe5a29084408c259ca3d1b5e6586ef78cdf8cff0b573c4d4->leave($__internal_c4c385fc2ff36383fe5a29084408c259ca3d1b5e6586ef78cdf8cff0b573c4d4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\submit_widget.html.php");
    }
}
