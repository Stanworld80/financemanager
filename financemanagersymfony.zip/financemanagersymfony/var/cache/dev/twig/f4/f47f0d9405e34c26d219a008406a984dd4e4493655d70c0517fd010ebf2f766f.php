<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_4f0ad35677d1e5cbfc45094a81bbae495ca5b05e96e822464f68931d35231ec0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56d5abe43129b65bc5d36c75ec72408920a97d9aaabf57324f94f4aec93961e1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_56d5abe43129b65bc5d36c75ec72408920a97d9aaabf57324f94f4aec93961e1->enter($__internal_56d5abe43129b65bc5d36c75ec72408920a97d9aaabf57324f94f4aec93961e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_44ce58adedc421d0c157054cf7d09a72a7e2a087edcc55b2d881da001e7c4d6e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44ce58adedc421d0c157054cf7d09a72a7e2a087edcc55b2d881da001e7c4d6e->enter($__internal_44ce58adedc421d0c157054cf7d09a72a7e2a087edcc55b2d881da001e7c4d6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_56d5abe43129b65bc5d36c75ec72408920a97d9aaabf57324f94f4aec93961e1->leave($__internal_56d5abe43129b65bc5d36c75ec72408920a97d9aaabf57324f94f4aec93961e1_prof);

        
        $__internal_44ce58adedc421d0c157054cf7d09a72a7e2a087edcc55b2d881da001e7c4d6e->leave($__internal_44ce58adedc421d0c157054cf7d09a72a7e2a087edcc55b2d881da001e7c4d6e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
