<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_6f31eb275bcfe2ff284ee4ce5a897064070e559597f9dbd071c2fb7b99842baf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b0e5e5f9411a210bcf7114d38f3f325625c398114f86cc3c06c023c82cf5bb45 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b0e5e5f9411a210bcf7114d38f3f325625c398114f86cc3c06c023c82cf5bb45->enter($__internal_b0e5e5f9411a210bcf7114d38f3f325625c398114f86cc3c06c023c82cf5bb45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_ade0eb240fa5d93678f109f30e85576676a6519eff1264eef0c59423573e2f35 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ade0eb240fa5d93678f109f30e85576676a6519eff1264eef0c59423573e2f35->enter($__internal_ade0eb240fa5d93678f109f30e85576676a6519eff1264eef0c59423573e2f35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_b0e5e5f9411a210bcf7114d38f3f325625c398114f86cc3c06c023c82cf5bb45->leave($__internal_b0e5e5f9411a210bcf7114d38f3f325625c398114f86cc3c06c023c82cf5bb45_prof);

        
        $__internal_ade0eb240fa5d93678f109f30e85576676a6519eff1264eef0c59423573e2f35->leave($__internal_ade0eb240fa5d93678f109f30e85576676a6519eff1264eef0c59423573e2f35_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
