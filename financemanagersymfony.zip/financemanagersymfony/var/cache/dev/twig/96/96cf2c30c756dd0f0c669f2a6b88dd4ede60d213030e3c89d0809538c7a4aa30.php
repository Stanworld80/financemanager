<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_95712cb5621cc7e9aadc0750b7264ba081c1b2e755c07cf5ac99faf4eb44463b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_40eeda708e36856959f0a482571c644399c4ebe22cab1b88e9774374f145db2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40eeda708e36856959f0a482571c644399c4ebe22cab1b88e9774374f145db2c->enter($__internal_40eeda708e36856959f0a482571c644399c4ebe22cab1b88e9774374f145db2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_5ba5fad1260514d3e8c4d992f9f708998696cadf6357923938acac3da0aff1ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ba5fad1260514d3e8c4d992f9f708998696cadf6357923938acac3da0aff1ee->enter($__internal_5ba5fad1260514d3e8c4d992f9f708998696cadf6357923938acac3da0aff1ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_40eeda708e36856959f0a482571c644399c4ebe22cab1b88e9774374f145db2c->leave($__internal_40eeda708e36856959f0a482571c644399c4ebe22cab1b88e9774374f145db2c_prof);

        
        $__internal_5ba5fad1260514d3e8c4d992f9f708998696cadf6357923938acac3da0aff1ee->leave($__internal_5ba5fad1260514d3e8c4d992f9f708998696cadf6357923938acac3da0aff1ee_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
