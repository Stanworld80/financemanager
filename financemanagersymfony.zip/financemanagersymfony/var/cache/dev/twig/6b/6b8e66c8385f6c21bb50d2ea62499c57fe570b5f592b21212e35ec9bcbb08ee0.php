<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_b4fdf6e81c1de259c397928c1c967a3bc5f9edb4626489208ce211ea7ac52aec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e8115a72ecaa5e9ffe138b79e1617b2f5b66cb0b052a8d8902876628a38db5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e8115a72ecaa5e9ffe138b79e1617b2f5b66cb0b052a8d8902876628a38db5f->enter($__internal_3e8115a72ecaa5e9ffe138b79e1617b2f5b66cb0b052a8d8902876628a38db5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_7a240e77dc83bc071a81cf30fa5b2a9de9bca54dc851d24dff0200f6a555fd98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a240e77dc83bc071a81cf30fa5b2a9de9bca54dc851d24dff0200f6a555fd98->enter($__internal_7a240e77dc83bc071a81cf30fa5b2a9de9bca54dc851d24dff0200f6a555fd98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_3e8115a72ecaa5e9ffe138b79e1617b2f5b66cb0b052a8d8902876628a38db5f->leave($__internal_3e8115a72ecaa5e9ffe138b79e1617b2f5b66cb0b052a8d8902876628a38db5f_prof);

        
        $__internal_7a240e77dc83bc071a81cf30fa5b2a9de9bca54dc851d24dff0200f6a555fd98->leave($__internal_7a240e77dc83bc071a81cf30fa5b2a9de9bca54dc851d24dff0200f6a555fd98_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
