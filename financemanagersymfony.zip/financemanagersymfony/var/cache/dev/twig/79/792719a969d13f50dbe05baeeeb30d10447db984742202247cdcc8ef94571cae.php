<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_9e1f39cc316dbded925ff69006bf06f639d30bcc75083a0c4320d29c2c1aaff9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8130735b6776631c4be222839b15c144e4d0d1170cecd9523c24b0d5b40a94c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8130735b6776631c4be222839b15c144e4d0d1170cecd9523c24b0d5b40a94c5->enter($__internal_8130735b6776631c4be222839b15c144e4d0d1170cecd9523c24b0d5b40a94c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_952faa325a876b51deb88c24ecb91c9309a71297ddad5ae32e4dee12749f4fee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_952faa325a876b51deb88c24ecb91c9309a71297ddad5ae32e4dee12749f4fee->enter($__internal_952faa325a876b51deb88c24ecb91c9309a71297ddad5ae32e4dee12749f4fee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_8130735b6776631c4be222839b15c144e4d0d1170cecd9523c24b0d5b40a94c5->leave($__internal_8130735b6776631c4be222839b15c144e4d0d1170cecd9523c24b0d5b40a94c5_prof);

        
        $__internal_952faa325a876b51deb88c24ecb91c9309a71297ddad5ae32e4dee12749f4fee->leave($__internal_952faa325a876b51deb88c24ecb91c9309a71297ddad5ae32e4dee12749f4fee_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_3a42587d7db3ebbf91ed3d0935db2b6c2a4525e40f930bbd42abb7eb779fdcd6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a42587d7db3ebbf91ed3d0935db2b6c2a4525e40f930bbd42abb7eb779fdcd6->enter($__internal_3a42587d7db3ebbf91ed3d0935db2b6c2a4525e40f930bbd42abb7eb779fdcd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_35a3895d3286b6ec7058a5c3448a1762a6e1f2da4ca1cb93217ede3119968944 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35a3895d3286b6ec7058a5c3448a1762a6e1f2da4ca1cb93217ede3119968944->enter($__internal_35a3895d3286b6ec7058a5c3448a1762a6e1f2da4ca1cb93217ede3119968944_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_35a3895d3286b6ec7058a5c3448a1762a6e1f2da4ca1cb93217ede3119968944->leave($__internal_35a3895d3286b6ec7058a5c3448a1762a6e1f2da4ca1cb93217ede3119968944_prof);

        
        $__internal_3a42587d7db3ebbf91ed3d0935db2b6c2a4525e40f930bbd42abb7eb779fdcd6->leave($__internal_3a42587d7db3ebbf91ed3d0935db2b6c2a4525e40f930bbd42abb7eb779fdcd6_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_5c0bea34215091a50b430ee4f549de728f03dac4dd9fadbb84a9e74322494bb7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c0bea34215091a50b430ee4f549de728f03dac4dd9fadbb84a9e74322494bb7->enter($__internal_5c0bea34215091a50b430ee4f549de728f03dac4dd9fadbb84a9e74322494bb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_2771fdb44537a335139c8fbc0c87bf3daa2efd6a259338bac14bcd920ee39578 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2771fdb44537a335139c8fbc0c87bf3daa2efd6a259338bac14bcd920ee39578->enter($__internal_2771fdb44537a335139c8fbc0c87bf3daa2efd6a259338bac14bcd920ee39578_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_2771fdb44537a335139c8fbc0c87bf3daa2efd6a259338bac14bcd920ee39578->leave($__internal_2771fdb44537a335139c8fbc0c87bf3daa2efd6a259338bac14bcd920ee39578_prof);

        
        $__internal_5c0bea34215091a50b430ee4f549de728f03dac4dd9fadbb84a9e74322494bb7->leave($__internal_5c0bea34215091a50b430ee4f549de728f03dac4dd9fadbb84a9e74322494bb7_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_bc47b13135f80a20c2cedaa837a3929f3fbcc7d7eaa87762cb11fcc67af551ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc47b13135f80a20c2cedaa837a3929f3fbcc7d7eaa87762cb11fcc67af551ff->enter($__internal_bc47b13135f80a20c2cedaa837a3929f3fbcc7d7eaa87762cb11fcc67af551ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1cf455924bf9c57e5fc529299db1070ef263c8e9f3d5cd4359a3078b48b3e2a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1cf455924bf9c57e5fc529299db1070ef263c8e9f3d5cd4359a3078b48b3e2a4->enter($__internal_1cf455924bf9c57e5fc529299db1070ef263c8e9f3d5cd4359a3078b48b3e2a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_1cf455924bf9c57e5fc529299db1070ef263c8e9f3d5cd4359a3078b48b3e2a4->leave($__internal_1cf455924bf9c57e5fc529299db1070ef263c8e9f3d5cd4359a3078b48b3e2a4_prof);

        
        $__internal_bc47b13135f80a20c2cedaa837a3929f3fbcc7d7eaa87762cb11fcc67af551ff->leave($__internal_bc47b13135f80a20c2cedaa837a3929f3fbcc7d7eaa87762cb11fcc67af551ff_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\layout.html.twig");
    }
}
