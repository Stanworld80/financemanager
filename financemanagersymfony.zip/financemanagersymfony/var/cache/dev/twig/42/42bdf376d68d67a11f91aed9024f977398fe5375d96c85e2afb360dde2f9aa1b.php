<?php

/* TwigBundle:Exception:error.xml.twig */
class __TwigTemplate_a759a908dd270e9b4504436f6763e257f38425ae400fa260a69062c667f07cdd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d3704e6ee2fa8bed0465e372d03e225d34087966587b077ee9ee1e0f9b35f5d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3704e6ee2fa8bed0465e372d03e225d34087966587b077ee9ee1e0f9b35f5d5->enter($__internal_d3704e6ee2fa8bed0465e372d03e225d34087966587b077ee9ee1e0f9b35f5d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        $__internal_eba3b7302752807fb3f450b919a6712f07ed003cbba9e0214e8950b19cd6bc32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eba3b7302752807fb3f450b919a6712f07ed003cbba9e0214e8950b19cd6bc32->enter($__internal_eba3b7302752807fb3f450b919a6712f07ed003cbba9e0214e8950b19cd6bc32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_d3704e6ee2fa8bed0465e372d03e225d34087966587b077ee9ee1e0f9b35f5d5->leave($__internal_d3704e6ee2fa8bed0465e372d03e225d34087966587b077ee9ee1e0f9b35f5d5_prof);

        
        $__internal_eba3b7302752807fb3f450b919a6712f07ed003cbba9e0214e8950b19cd6bc32->leave($__internal_eba3b7302752807fb3f450b919a6712f07ed003cbba9e0214e8950b19cd6bc32_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"{{ _charset }}\" ?>

<error code=\"{{ status_code }}\" message=\"{{ status_text }}\" />
", "TwigBundle:Exception:error.xml.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.xml.twig");
    }
}
