<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_4970a05da6c8ec585c2cccd699a26d76b4d348bb4f2715acf4fe284f570839ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de1ec3364294f9eeb3347ec91ba11f556529270360fd5bfd6a962931b5fefe1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de1ec3364294f9eeb3347ec91ba11f556529270360fd5bfd6a962931b5fefe1b->enter($__internal_de1ec3364294f9eeb3347ec91ba11f556529270360fd5bfd6a962931b5fefe1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_a7f617b86d4416c1b4375832cb654e29af4a667871b15e42b4c88f99d3df72a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7f617b86d4416c1b4375832cb654e29af4a667871b15e42b4c88f99d3df72a8->enter($__internal_a7f617b86d4416c1b4375832cb654e29af4a667871b15e42b4c88f99d3df72a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_de1ec3364294f9eeb3347ec91ba11f556529270360fd5bfd6a962931b5fefe1b->leave($__internal_de1ec3364294f9eeb3347ec91ba11f556529270360fd5bfd6a962931b5fefe1b_prof);

        
        $__internal_a7f617b86d4416c1b4375832cb654e29af4a667871b15e42b4c88f99d3df72a8->leave($__internal_a7f617b86d4416c1b4375832cb654e29af4a667871b15e42b4c88f99d3df72a8_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_6014232da13c3d3b30bf9ded759eb8ed85d608d2b2587e4d77166db24be6a972 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6014232da13c3d3b30bf9ded759eb8ed85d608d2b2587e4d77166db24be6a972->enter($__internal_6014232da13c3d3b30bf9ded759eb8ed85d608d2b2587e4d77166db24be6a972_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9e8df59ad8a0eb488425c81e0c096507ee19fa679def4c3a42be0c5a02e77bee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e8df59ad8a0eb488425c81e0c096507ee19fa679def4c3a42be0c5a02e77bee->enter($__internal_9e8df59ad8a0eb488425c81e0c096507ee19fa679def4c3a42be0c5a02e77bee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_9e8df59ad8a0eb488425c81e0c096507ee19fa679def4c3a42be0c5a02e77bee->leave($__internal_9e8df59ad8a0eb488425c81e0c096507ee19fa679def4c3a42be0c5a02e77bee_prof);

        
        $__internal_6014232da13c3d3b30bf9ded759eb8ed85d608d2b2587e4d77166db24be6a972->leave($__internal_6014232da13c3d3b30bf9ded759eb8ed85d608d2b2587e4d77166db24be6a972_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
