<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_d07e9508ee4a2ce5cabe0f56f327e648e6199659feb57db5a513b73c0eb7a406 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8eca2828d828428ba3ccd814bcdc587b75bd7af6e9b6c3e63bc8ef6a32e11a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8eca2828d828428ba3ccd814bcdc587b75bd7af6e9b6c3e63bc8ef6a32e11a7->enter($__internal_e8eca2828d828428ba3ccd814bcdc587b75bd7af6e9b6c3e63bc8ef6a32e11a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_b21472ebf9730b67b1af09cefab4c483b58b15276b0be69446784bb8c7a694a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b21472ebf9730b67b1af09cefab4c483b58b15276b0be69446784bb8c7a694a1->enter($__internal_b21472ebf9730b67b1af09cefab4c483b58b15276b0be69446784bb8c7a694a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_e8eca2828d828428ba3ccd814bcdc587b75bd7af6e9b6c3e63bc8ef6a32e11a7->leave($__internal_e8eca2828d828428ba3ccd814bcdc587b75bd7af6e9b6c3e63bc8ef6a32e11a7_prof);

        
        $__internal_b21472ebf9730b67b1af09cefab4c483b58b15276b0be69446784bb8c7a694a1->leave($__internal_b21472ebf9730b67b1af09cefab4c483b58b15276b0be69446784bb8c7a694a1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
