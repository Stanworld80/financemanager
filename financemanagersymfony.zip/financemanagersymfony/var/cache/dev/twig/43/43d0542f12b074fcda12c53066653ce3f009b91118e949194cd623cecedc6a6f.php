<?php

/* base.html.twig */
class __TwigTemplate_35a788ca461558bba9038e4c3f84ff08bc8c4a644fa3eb1893a42b9f45e0624c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dab98b175629b6ad9eab71cba06941e487fb98df0cea5b08dc6e7206ceef4d08 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dab98b175629b6ad9eab71cba06941e487fb98df0cea5b08dc6e7206ceef4d08->enter($__internal_dab98b175629b6ad9eab71cba06941e487fb98df0cea5b08dc6e7206ceef4d08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_c6a8533142bd58c9a4e6602c12702caf99767e343fe4832f1eb4e27509ee0d59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6a8533142bd58c9a4e6602c12702caf99767e343fe4832f1eb4e27509ee0d59->enter($__internal_c6a8533142bd58c9a4e6602c12702caf99767e343fe4832f1eb4e27509ee0d59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_dab98b175629b6ad9eab71cba06941e487fb98df0cea5b08dc6e7206ceef4d08->leave($__internal_dab98b175629b6ad9eab71cba06941e487fb98df0cea5b08dc6e7206ceef4d08_prof);

        
        $__internal_c6a8533142bd58c9a4e6602c12702caf99767e343fe4832f1eb4e27509ee0d59->leave($__internal_c6a8533142bd58c9a4e6602c12702caf99767e343fe4832f1eb4e27509ee0d59_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_fe7e1b7da6510a2c96b2ee56ee8269ba32a44ce76e1119e9e681c47f36dad309 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe7e1b7da6510a2c96b2ee56ee8269ba32a44ce76e1119e9e681c47f36dad309->enter($__internal_fe7e1b7da6510a2c96b2ee56ee8269ba32a44ce76e1119e9e681c47f36dad309_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_66bcd8455f8e08679912d4393487ff7b600b4e64a163aef2a0434bdd2b8246ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66bcd8455f8e08679912d4393487ff7b600b4e64a163aef2a0434bdd2b8246ea->enter($__internal_66bcd8455f8e08679912d4393487ff7b600b4e64a163aef2a0434bdd2b8246ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_66bcd8455f8e08679912d4393487ff7b600b4e64a163aef2a0434bdd2b8246ea->leave($__internal_66bcd8455f8e08679912d4393487ff7b600b4e64a163aef2a0434bdd2b8246ea_prof);

        
        $__internal_fe7e1b7da6510a2c96b2ee56ee8269ba32a44ce76e1119e9e681c47f36dad309->leave($__internal_fe7e1b7da6510a2c96b2ee56ee8269ba32a44ce76e1119e9e681c47f36dad309_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_cb01e4ca0a4f3abdd50e81636e31e42fbace6b71d3969967e654d8fe9b6f2c8c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb01e4ca0a4f3abdd50e81636e31e42fbace6b71d3969967e654d8fe9b6f2c8c->enter($__internal_cb01e4ca0a4f3abdd50e81636e31e42fbace6b71d3969967e654d8fe9b6f2c8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_a35f959aeea666921f498d9944cfefa450a11ee6b93246de5d9f7b2dd0f2846c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a35f959aeea666921f498d9944cfefa450a11ee6b93246de5d9f7b2dd0f2846c->enter($__internal_a35f959aeea666921f498d9944cfefa450a11ee6b93246de5d9f7b2dd0f2846c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_a35f959aeea666921f498d9944cfefa450a11ee6b93246de5d9f7b2dd0f2846c->leave($__internal_a35f959aeea666921f498d9944cfefa450a11ee6b93246de5d9f7b2dd0f2846c_prof);

        
        $__internal_cb01e4ca0a4f3abdd50e81636e31e42fbace6b71d3969967e654d8fe9b6f2c8c->leave($__internal_cb01e4ca0a4f3abdd50e81636e31e42fbace6b71d3969967e654d8fe9b6f2c8c_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_a0167e7ce7e6c6d1437a4f5a569290bcd44fc987059f728f1d883e6250c01bfa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0167e7ce7e6c6d1437a4f5a569290bcd44fc987059f728f1d883e6250c01bfa->enter($__internal_a0167e7ce7e6c6d1437a4f5a569290bcd44fc987059f728f1d883e6250c01bfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d16b4b5d20b5d71b958c03900e22a732493daa12b25e1bfaa6a7b098d8fbf53e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d16b4b5d20b5d71b958c03900e22a732493daa12b25e1bfaa6a7b098d8fbf53e->enter($__internal_d16b4b5d20b5d71b958c03900e22a732493daa12b25e1bfaa6a7b098d8fbf53e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_d16b4b5d20b5d71b958c03900e22a732493daa12b25e1bfaa6a7b098d8fbf53e->leave($__internal_d16b4b5d20b5d71b958c03900e22a732493daa12b25e1bfaa6a7b098d8fbf53e_prof);

        
        $__internal_a0167e7ce7e6c6d1437a4f5a569290bcd44fc987059f728f1d883e6250c01bfa->leave($__internal_a0167e7ce7e6c6d1437a4f5a569290bcd44fc987059f728f1d883e6250c01bfa_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_41b1d7f839bf1759cb3ad72957ad30526616a46bb68ee682fb7595110f12ce40 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41b1d7f839bf1759cb3ad72957ad30526616a46bb68ee682fb7595110f12ce40->enter($__internal_41b1d7f839bf1759cb3ad72957ad30526616a46bb68ee682fb7595110f12ce40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_e9e22379cc13c8d1016b77288dd9b17ecedcf30564c1c430bd9c289ef7cb1114 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9e22379cc13c8d1016b77288dd9b17ecedcf30564c1c430bd9c289ef7cb1114->enter($__internal_e9e22379cc13c8d1016b77288dd9b17ecedcf30564c1c430bd9c289ef7cb1114_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_e9e22379cc13c8d1016b77288dd9b17ecedcf30564c1c430bd9c289ef7cb1114->leave($__internal_e9e22379cc13c8d1016b77288dd9b17ecedcf30564c1c430bd9c289ef7cb1114_prof);

        
        $__internal_41b1d7f839bf1759cb3ad72957ad30526616a46bb68ee682fb7595110f12ce40->leave($__internal_41b1d7f839bf1759cb3ad72957ad30526616a46bb68ee682fb7595110f12ce40_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\app\\Resources\\views\\base.html.twig");
    }
}
