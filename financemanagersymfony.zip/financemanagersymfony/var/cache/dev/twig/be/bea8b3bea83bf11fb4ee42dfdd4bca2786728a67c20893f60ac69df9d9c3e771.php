<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_12578b539e9f6c1173c6256a7d2d44209590d6b3e2b2dd510ee73141041d0d3f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_86f48d6483f5accbba94ed7e9120fe11d215e0e21077c7e3b4ebbfd334658bc2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_86f48d6483f5accbba94ed7e9120fe11d215e0e21077c7e3b4ebbfd334658bc2->enter($__internal_86f48d6483f5accbba94ed7e9120fe11d215e0e21077c7e3b4ebbfd334658bc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_b82e3dd1452fef404bf49d193b10adbbadfe1a278b0e201044fe53335a67f842 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b82e3dd1452fef404bf49d193b10adbbadfe1a278b0e201044fe53335a67f842->enter($__internal_b82e3dd1452fef404bf49d193b10adbbadfe1a278b0e201044fe53335a67f842_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
";
        
        $__internal_86f48d6483f5accbba94ed7e9120fe11d215e0e21077c7e3b4ebbfd334658bc2->leave($__internal_86f48d6483f5accbba94ed7e9120fe11d215e0e21077c7e3b4ebbfd334658bc2_prof);

        
        $__internal_b82e3dd1452fef404bf49d193b10adbbadfe1a278b0e201044fe53335a67f842->leave($__internal_b82e3dd1452fef404bf49d193b10adbbadfe1a278b0e201044fe53335a67f842_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_widget_compound.html.php");
    }
}
