<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_089b0ddbce0f3f5a4bbfa0fbe134fcaebc31633e3d39ad91f75ae3d0de4e4967 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f4377651a2f3116e9e1aee00fd725c82b5f29d2534878080416620e505eacfc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f4377651a2f3116e9e1aee00fd725c82b5f29d2534878080416620e505eacfc->enter($__internal_8f4377651a2f3116e9e1aee00fd725c82b5f29d2534878080416620e505eacfc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_ca5a5fc5e4f8a541dceff733573fb628f9090c0e6abeb27663bfcff47c0e49ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca5a5fc5e4f8a541dceff733573fb628f9090c0e6abeb27663bfcff47c0e49ed->enter($__internal_ca5a5fc5e4f8a541dceff733573fb628f9090c0e6abeb27663bfcff47c0e49ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_8f4377651a2f3116e9e1aee00fd725c82b5f29d2534878080416620e505eacfc->leave($__internal_8f4377651a2f3116e9e1aee00fd725c82b5f29d2534878080416620e505eacfc_prof);

        
        $__internal_ca5a5fc5e4f8a541dceff733573fb628f9090c0e6abeb27663bfcff47c0e49ed->leave($__internal_ca5a5fc5e4f8a541dceff733573fb628f9090c0e6abeb27663bfcff47c0e49ed_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget_expanded.html.php");
    }
}
