<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_91696a6e0cc9aad2b2a6ffbbf8651f1b29e3cbc2e48bd5dda9ee8ccabf53e928 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_94aa8af383eb986dfd12479892f027a1ccbcb581ce62a421952aee1f97360cd5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_94aa8af383eb986dfd12479892f027a1ccbcb581ce62a421952aee1f97360cd5->enter($__internal_94aa8af383eb986dfd12479892f027a1ccbcb581ce62a421952aee1f97360cd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_63c2a6d22fc688cf89a82b7332412f49725646a6f7739b498fab7b4c9bbf13a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63c2a6d22fc688cf89a82b7332412f49725646a6f7739b498fab7b4c9bbf13a9->enter($__internal_63c2a6d22fc688cf89a82b7332412f49725646a6f7739b498fab7b4c9bbf13a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_94aa8af383eb986dfd12479892f027a1ccbcb581ce62a421952aee1f97360cd5->leave($__internal_94aa8af383eb986dfd12479892f027a1ccbcb581ce62a421952aee1f97360cd5_prof);

        
        $__internal_63c2a6d22fc688cf89a82b7332412f49725646a6f7739b498fab7b4c9bbf13a9->leave($__internal_63c2a6d22fc688cf89a82b7332412f49725646a6f7739b498fab7b4c9bbf13a9_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_0d3646042d435e540aa5ca6329a0a65cd3e30d7482dc79d650e006aabc9d547c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d3646042d435e540aa5ca6329a0a65cd3e30d7482dc79d650e006aabc9d547c->enter($__internal_0d3646042d435e540aa5ca6329a0a65cd3e30d7482dc79d650e006aabc9d547c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_18904d619ccad0160f921c7988e43e1c31123edd04ce777ee8a5001be97a76fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18904d619ccad0160f921c7988e43e1c31123edd04ce777ee8a5001be97a76fa->enter($__internal_18904d619ccad0160f921c7988e43e1c31123edd04ce777ee8a5001be97a76fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_18904d619ccad0160f921c7988e43e1c31123edd04ce777ee8a5001be97a76fa->leave($__internal_18904d619ccad0160f921c7988e43e1c31123edd04ce777ee8a5001be97a76fa_prof);

        
        $__internal_0d3646042d435e540aa5ca6329a0a65cd3e30d7482dc79d650e006aabc9d547c->leave($__internal_0d3646042d435e540aa5ca6329a0a65cd3e30d7482dc79d650e006aabc9d547c_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_9cf35037c5afdc53dd12ea2b5a84847724e24329c8cfaa3329187ba6e6c55e03 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9cf35037c5afdc53dd12ea2b5a84847724e24329c8cfaa3329187ba6e6c55e03->enter($__internal_9cf35037c5afdc53dd12ea2b5a84847724e24329c8cfaa3329187ba6e6c55e03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9324fd1d2d58bdb0d93280956fdaef58fe9b2323cd87a2aa0b114319cc55fd3b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9324fd1d2d58bdb0d93280956fdaef58fe9b2323cd87a2aa0b114319cc55fd3b->enter($__internal_9324fd1d2d58bdb0d93280956fdaef58fe9b2323cd87a2aa0b114319cc55fd3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_9324fd1d2d58bdb0d93280956fdaef58fe9b2323cd87a2aa0b114319cc55fd3b->leave($__internal_9324fd1d2d58bdb0d93280956fdaef58fe9b2323cd87a2aa0b114319cc55fd3b_prof);

        
        $__internal_9cf35037c5afdc53dd12ea2b5a84847724e24329c8cfaa3329187ba6e6c55e03->leave($__internal_9cf35037c5afdc53dd12ea2b5a84847724e24329c8cfaa3329187ba6e6c55e03_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
