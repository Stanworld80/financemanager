<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_ebc4c8ff5563da45d121e1741d8a0433c353ed68cc82ceb900c5c50db721629e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16b0abca25828d35e193a32b71669b40d0322789942ebf2927648d7a8350b6e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16b0abca25828d35e193a32b71669b40d0322789942ebf2927648d7a8350b6e8->enter($__internal_16b0abca25828d35e193a32b71669b40d0322789942ebf2927648d7a8350b6e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_59a11b6bcc918edb96f185b423fe3b3c0ad9cfacee91dd1bede90b978c3a6cbb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59a11b6bcc918edb96f185b423fe3b3c0ad9cfacee91dd1bede90b978c3a6cbb->enter($__internal_59a11b6bcc918edb96f185b423fe3b3c0ad9cfacee91dd1bede90b978c3a6cbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_16b0abca25828d35e193a32b71669b40d0322789942ebf2927648d7a8350b6e8->leave($__internal_16b0abca25828d35e193a32b71669b40d0322789942ebf2927648d7a8350b6e8_prof);

        
        $__internal_59a11b6bcc918edb96f185b423fe3b3c0ad9cfacee91dd1bede90b978c3a6cbb->leave($__internal_59a11b6bcc918edb96f185b423fe3b3c0ad9cfacee91dd1bede90b978c3a6cbb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
