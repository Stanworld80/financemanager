<?php

/* @Twig/Exception/error.xml.twig */
class __TwigTemplate_27ad885b101a9da558cfdb8aeff587abc7e66721b0fe4d6567ff2f3345f51121 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fb6b742b1942a9c7ef7e0f64065a3e64e5dc51a5eab7753798b3a84a19a4c45 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4fb6b742b1942a9c7ef7e0f64065a3e64e5dc51a5eab7753798b3a84a19a4c45->enter($__internal_4fb6b742b1942a9c7ef7e0f64065a3e64e5dc51a5eab7753798b3a84a19a4c45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.xml.twig"));

        $__internal_be80bff3b400d5a9796790a5149191d0addb711be622b232ed8d67468d4edf79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be80bff3b400d5a9796790a5149191d0addb711be622b232ed8d67468d4edf79->enter($__internal_be80bff3b400d5a9796790a5149191d0addb711be622b232ed8d67468d4edf79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_4fb6b742b1942a9c7ef7e0f64065a3e64e5dc51a5eab7753798b3a84a19a4c45->leave($__internal_4fb6b742b1942a9c7ef7e0f64065a3e64e5dc51a5eab7753798b3a84a19a4c45_prof);

        
        $__internal_be80bff3b400d5a9796790a5149191d0addb711be622b232ed8d67468d4edf79->leave($__internal_be80bff3b400d5a9796790a5149191d0addb711be622b232ed8d67468d4edf79_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"{{ _charset }}\" ?>

<error code=\"{{ status_code }}\" message=\"{{ status_text }}\" />
", "@Twig/Exception/error.xml.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.xml.twig");
    }
}
