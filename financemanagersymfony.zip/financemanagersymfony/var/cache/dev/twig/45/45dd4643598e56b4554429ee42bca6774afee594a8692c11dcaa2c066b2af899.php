<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_c9428ef6ba41514c21537094d87f26101cea5c7b772695a152cb2b598b5ac52f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6d99f5a4ee9bbc00f2612b057379e50fe9002a24353d4d10cb5f6f148c881a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6d99f5a4ee9bbc00f2612b057379e50fe9002a24353d4d10cb5f6f148c881a5->enter($__internal_c6d99f5a4ee9bbc00f2612b057379e50fe9002a24353d4d10cb5f6f148c881a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_c11de5d7980e77da501430291f2f3cfb11fd7526196d742f5f19ef2708092c3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c11de5d7980e77da501430291f2f3cfb11fd7526196d742f5f19ef2708092c3c->enter($__internal_c11de5d7980e77da501430291f2f3cfb11fd7526196d742f5f19ef2708092c3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_c6d99f5a4ee9bbc00f2612b057379e50fe9002a24353d4d10cb5f6f148c881a5->leave($__internal_c6d99f5a4ee9bbc00f2612b057379e50fe9002a24353d4d10cb5f6f148c881a5_prof);

        
        $__internal_c11de5d7980e77da501430291f2f3cfb11fd7526196d742f5f19ef2708092c3c->leave($__internal_c11de5d7980e77da501430291f2f3cfb11fd7526196d742f5f19ef2708092c3c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
