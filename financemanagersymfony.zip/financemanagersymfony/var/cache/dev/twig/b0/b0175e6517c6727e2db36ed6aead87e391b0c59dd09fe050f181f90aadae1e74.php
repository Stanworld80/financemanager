<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_ab75f73eb3264a7290edbfea7e04927f25a38c35f2120a145d3af15fee363549 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6ddc39327f596bdb391963f9682dae7d94d748d5c849cc1dcb63827a6b16cf95 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ddc39327f596bdb391963f9682dae7d94d748d5c849cc1dcb63827a6b16cf95->enter($__internal_6ddc39327f596bdb391963f9682dae7d94d748d5c849cc1dcb63827a6b16cf95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_8253f43dfd4d040d42422e050ab63dc1e240f1bdf73847d15005d44ba1683a9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8253f43dfd4d040d42422e050ab63dc1e240f1bdf73847d15005d44ba1683a9e->enter($__internal_8253f43dfd4d040d42422e050ab63dc1e240f1bdf73847d15005d44ba1683a9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_6ddc39327f596bdb391963f9682dae7d94d748d5c849cc1dcb63827a6b16cf95->leave($__internal_6ddc39327f596bdb391963f9682dae7d94d748d5c849cc1dcb63827a6b16cf95_prof);

        
        $__internal_8253f43dfd4d040d42422e050ab63dc1e240f1bdf73847d15005d44ba1683a9e->leave($__internal_8253f43dfd4d040d42422e050ab63dc1e240f1bdf73847d15005d44ba1683a9e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
