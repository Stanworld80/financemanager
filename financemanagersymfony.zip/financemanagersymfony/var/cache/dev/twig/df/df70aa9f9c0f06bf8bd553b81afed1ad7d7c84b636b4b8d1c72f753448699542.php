<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_b3c721221b590bc6ff7906c3f841c758d56c085b6fa2b9f997e202488bda381d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4cb2b8c8cbf6bc96e8c147d6db4898e6553e66ea14250f54179e258525d73870 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4cb2b8c8cbf6bc96e8c147d6db4898e6553e66ea14250f54179e258525d73870->enter($__internal_4cb2b8c8cbf6bc96e8c147d6db4898e6553e66ea14250f54179e258525d73870_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_e392ef9c49c408a7fe64d992080ad68f28d5fd3aba1cee557526cb3e9b7951e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e392ef9c49c408a7fe64d992080ad68f28d5fd3aba1cee557526cb3e9b7951e7->enter($__internal_e392ef9c49c408a7fe64d992080ad68f28d5fd3aba1cee557526cb3e9b7951e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_4cb2b8c8cbf6bc96e8c147d6db4898e6553e66ea14250f54179e258525d73870->leave($__internal_4cb2b8c8cbf6bc96e8c147d6db4898e6553e66ea14250f54179e258525d73870_prof);

        
        $__internal_e392ef9c49c408a7fe64d992080ad68f28d5fd3aba1cee557526cb3e9b7951e7->leave($__internal_e392ef9c49c408a7fe64d992080ad68f28d5fd3aba1cee557526cb3e9b7951e7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
