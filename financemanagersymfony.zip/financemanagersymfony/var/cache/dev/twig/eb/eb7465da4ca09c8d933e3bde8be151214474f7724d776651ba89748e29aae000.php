<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_3e0701d7c83b0af07679b170556d693b8b3ba7a4ac1b6849f510fd044c68e189 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a298eba7d82b48c80bb0b6a7880a82e0fdd725c808175fc4081e9a0bfaca86b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a298eba7d82b48c80bb0b6a7880a82e0fdd725c808175fc4081e9a0bfaca86b9->enter($__internal_a298eba7d82b48c80bb0b6a7880a82e0fdd725c808175fc4081e9a0bfaca86b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_b3ec0e2dbbec7b3ad2600399887b0483001f2e43d50296c752cd5670333ccfae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3ec0e2dbbec7b3ad2600399887b0483001f2e43d50296c752cd5670333ccfae->enter($__internal_b3ec0e2dbbec7b3ad2600399887b0483001f2e43d50296c752cd5670333ccfae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_a298eba7d82b48c80bb0b6a7880a82e0fdd725c808175fc4081e9a0bfaca86b9->leave($__internal_a298eba7d82b48c80bb0b6a7880a82e0fdd725c808175fc4081e9a0bfaca86b9_prof);

        
        $__internal_b3ec0e2dbbec7b3ad2600399887b0483001f2e43d50296c752cd5670333ccfae->leave($__internal_b3ec0e2dbbec7b3ad2600399887b0483001f2e43d50296c752cd5670333ccfae_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
