<?php

/* bootstrap_3_layout.html.twig */
class __TwigTemplate_5526634d00e1b3c0fe3d49e51a5d49e6c66d009014c14d98275452aad1d77274 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "bootstrap_3_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'textarea_widget' => array($this, 'block_textarea_widget'),
                'button_widget' => array($this, 'block_button_widget'),
                'money_widget' => array($this, 'block_money_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'choice_widget_collapsed' => array($this, 'block_choice_widget_collapsed'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'form_label' => array($this, 'block_form_label'),
                'choice_label' => array($this, 'block_choice_label'),
                'checkbox_label' => array($this, 'block_checkbox_label'),
                'radio_label' => array($this, 'block_radio_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'choice_row' => array($this, 'block_choice_row'),
                'date_row' => array($this, 'block_date_row'),
                'time_row' => array($this, 'block_time_row'),
                'datetime_row' => array($this, 'block_datetime_row'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
                'radio_row' => array($this, 'block_radio_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e4cf0bd318a4ec89fa8aa14f03a4852607d7384338b86ec72010a97e54a689f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e4cf0bd318a4ec89fa8aa14f03a4852607d7384338b86ec72010a97e54a689f->enter($__internal_1e4cf0bd318a4ec89fa8aa14f03a4852607d7384338b86ec72010a97e54a689f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        $__internal_2c31a8ed6248747386be63a505fb57f4904c8b00d19d34b4de548925b857a925 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c31a8ed6248747386be63a505fb57f4904c8b00d19d34b4de548925b857a925->enter($__internal_2c31a8ed6248747386be63a505fb57f4904c8b00d19d34b4de548925b857a925_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 11
        echo "
";
        // line 12
        $this->displayBlock('textarea_widget', $context, $blocks);
        // line 16
        echo "
";
        // line 17
        $this->displayBlock('button_widget', $context, $blocks);
        // line 21
        echo "
";
        // line 22
        $this->displayBlock('money_widget', $context, $blocks);
        // line 34
        echo "
";
        // line 35
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 41
        echo "
";
        // line 42
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 55
        echo "
";
        // line 56
        $this->displayBlock('date_widget', $context, $blocks);
        // line 74
        echo "
";
        // line 75
        $this->displayBlock('time_widget', $context, $blocks);
        // line 90
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 128
        $this->displayBlock('choice_widget_collapsed', $context, $blocks);
        // line 132
        echo "
";
        // line 133
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 152
        echo "
";
        // line 153
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 163
        echo "
";
        // line 164
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 174
        echo "
";
        // line 176
        echo "
";
        // line 177
        $this->displayBlock('form_label', $context, $blocks);
        // line 181
        echo "
";
        // line 182
        $this->displayBlock('choice_label', $context, $blocks);
        // line 187
        echo "
";
        // line 188
        $this->displayBlock('checkbox_label', $context, $blocks);
        // line 193
        echo "
";
        // line 194
        $this->displayBlock('radio_label', $context, $blocks);
        // line 199
        echo "
";
        // line 200
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 224
        echo "
";
        // line 226
        echo "
";
        // line 227
        $this->displayBlock('form_row', $context, $blocks);
        // line 234
        echo "
";
        // line 235
        $this->displayBlock('button_row', $context, $blocks);
        // line 240
        echo "
";
        // line 241
        $this->displayBlock('choice_row', $context, $blocks);
        // line 245
        echo "
";
        // line 246
        $this->displayBlock('date_row', $context, $blocks);
        // line 250
        echo "
";
        // line 251
        $this->displayBlock('time_row', $context, $blocks);
        // line 255
        echo "
";
        // line 256
        $this->displayBlock('datetime_row', $context, $blocks);
        // line 260
        echo "
";
        // line 261
        $this->displayBlock('checkbox_row', $context, $blocks);
        // line 267
        echo "
";
        // line 268
        $this->displayBlock('radio_row', $context, $blocks);
        // line 274
        echo "
";
        // line 276
        echo "
";
        // line 277
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_1e4cf0bd318a4ec89fa8aa14f03a4852607d7384338b86ec72010a97e54a689f->leave($__internal_1e4cf0bd318a4ec89fa8aa14f03a4852607d7384338b86ec72010a97e54a689f_prof);

        
        $__internal_2c31a8ed6248747386be63a505fb57f4904c8b00d19d34b4de548925b857a925->leave($__internal_2c31a8ed6248747386be63a505fb57f4904c8b00d19d34b4de548925b857a925_prof);

    }

    // line 5
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_387f22c4530d7e0e4242bbeffbde7c7488506e77db9f4cfcf29f4159d9b49bed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_387f22c4530d7e0e4242bbeffbde7c7488506e77db9f4cfcf29f4159d9b49bed->enter($__internal_387f22c4530d7e0e4242bbeffbde7c7488506e77db9f4cfcf29f4159d9b49bed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_c01f48cd54d6704c5c8a86baf8857eeb2872cb025bf1e36f99d50a13a394734f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c01f48cd54d6704c5c8a86baf8857eeb2872cb025bf1e36f99d50a13a394734f->enter($__internal_c01f48cd54d6704c5c8a86baf8857eeb2872cb025bf1e36f99d50a13a394734f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 6
        if (( !array_key_exists("type", $context) || !twig_in_filter(($context["type"] ?? $this->getContext($context, "type")), array(0 => "file", 1 => "hidden")))) {
            // line 7
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        }
        // line 9
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_c01f48cd54d6704c5c8a86baf8857eeb2872cb025bf1e36f99d50a13a394734f->leave($__internal_c01f48cd54d6704c5c8a86baf8857eeb2872cb025bf1e36f99d50a13a394734f_prof);

        
        $__internal_387f22c4530d7e0e4242bbeffbde7c7488506e77db9f4cfcf29f4159d9b49bed->leave($__internal_387f22c4530d7e0e4242bbeffbde7c7488506e77db9f4cfcf29f4159d9b49bed_prof);

    }

    // line 12
    public function block_textarea_widget($context, array $blocks = array())
    {
        $__internal_f1403a94d4831c7671399312d7e23380d908e4a1a63b2c1b18d96c26f6d96e70 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1403a94d4831c7671399312d7e23380d908e4a1a63b2c1b18d96c26f6d96e70->enter($__internal_f1403a94d4831c7671399312d7e23380d908e4a1a63b2c1b18d96c26f6d96e70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        $__internal_90771a5f532cbe45ecbf94b494f3d372ff0171865062b7f2704f6b86eaf94da8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90771a5f532cbe45ecbf94b494f3d372ff0171865062b7f2704f6b86eaf94da8->enter($__internal_90771a5f532cbe45ecbf94b494f3d372ff0171865062b7f2704f6b86eaf94da8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        // line 13
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 14
        $this->displayParentBlock("textarea_widget", $context, $blocks);
        
        $__internal_90771a5f532cbe45ecbf94b494f3d372ff0171865062b7f2704f6b86eaf94da8->leave($__internal_90771a5f532cbe45ecbf94b494f3d372ff0171865062b7f2704f6b86eaf94da8_prof);

        
        $__internal_f1403a94d4831c7671399312d7e23380d908e4a1a63b2c1b18d96c26f6d96e70->leave($__internal_f1403a94d4831c7671399312d7e23380d908e4a1a63b2c1b18d96c26f6d96e70_prof);

    }

    // line 17
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_3ad93ad1672aba696d78306af50b9a55c450e6861b4dbde4c7b064577954e7f2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ad93ad1672aba696d78306af50b9a55c450e6861b4dbde4c7b064577954e7f2->enter($__internal_3ad93ad1672aba696d78306af50b9a55c450e6861b4dbde4c7b064577954e7f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_15640df2b2e47b8a95556ce408d37d343d6ea2e55593af5e6d13913e6832baa2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15640df2b2e47b8a95556ce408d37d343d6ea2e55593af5e6d13913e6832baa2->enter($__internal_15640df2b2e47b8a95556ce408d37d343d6ea2e55593af5e6d13913e6832baa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 18
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-default")) : ("btn-default")) . " btn"))));
        // line 19
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_15640df2b2e47b8a95556ce408d37d343d6ea2e55593af5e6d13913e6832baa2->leave($__internal_15640df2b2e47b8a95556ce408d37d343d6ea2e55593af5e6d13913e6832baa2_prof);

        
        $__internal_3ad93ad1672aba696d78306af50b9a55c450e6861b4dbde4c7b064577954e7f2->leave($__internal_3ad93ad1672aba696d78306af50b9a55c450e6861b4dbde4c7b064577954e7f2_prof);

    }

    // line 22
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_1a4bf1b5094ea4088fb3bd70db6110e597ad78d4e414365bbe7caf747d993721 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a4bf1b5094ea4088fb3bd70db6110e597ad78d4e414365bbe7caf747d993721->enter($__internal_1a4bf1b5094ea4088fb3bd70db6110e597ad78d4e414365bbe7caf747d993721_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_551bcd8b5d2de75b212c756a59bf3b6398e834ff78b06ea391714c2a3fd0ff0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_551bcd8b5d2de75b212c756a59bf3b6398e834ff78b06ea391714c2a3fd0ff0a->enter($__internal_551bcd8b5d2de75b212c756a59bf3b6398e834ff78b06ea391714c2a3fd0ff0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 23
        echo "<div class=\"input-group\">
        ";
        // line 24
        $context["append"] = (is_string($__internal_25a370af2cfa9fd61845d6f76a288d55939841bbea6e8f8b476b87f6d10407d0 = ($context["money_pattern"] ?? $this->getContext($context, "money_pattern"))) && is_string($__internal_bcc278f719611e1ad92d4719349917ee489141140ae7dce5dd0d6332995d07cd = "{{") && ('' === $__internal_bcc278f719611e1ad92d4719349917ee489141140ae7dce5dd0d6332995d07cd || 0 === strpos($__internal_25a370af2cfa9fd61845d6f76a288d55939841bbea6e8f8b476b87f6d10407d0, $__internal_bcc278f719611e1ad92d4719349917ee489141140ae7dce5dd0d6332995d07cd)));
        // line 25
        echo "        ";
        if ( !($context["append"] ?? $this->getContext($context, "append"))) {
            // line 26
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 28
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 29
        if (($context["append"] ?? $this->getContext($context, "append"))) {
            // line 30
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 32
        echo "    </div>";
        
        $__internal_551bcd8b5d2de75b212c756a59bf3b6398e834ff78b06ea391714c2a3fd0ff0a->leave($__internal_551bcd8b5d2de75b212c756a59bf3b6398e834ff78b06ea391714c2a3fd0ff0a_prof);

        
        $__internal_1a4bf1b5094ea4088fb3bd70db6110e597ad78d4e414365bbe7caf747d993721->leave($__internal_1a4bf1b5094ea4088fb3bd70db6110e597ad78d4e414365bbe7caf747d993721_prof);

    }

    // line 35
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_bc685070c568b9992a09e7ddba23b8d716daa79c88542d616000753776db2490 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc685070c568b9992a09e7ddba23b8d716daa79c88542d616000753776db2490->enter($__internal_bc685070c568b9992a09e7ddba23b8d716daa79c88542d616000753776db2490_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_affa77b2bcedc0262632bafb6d83994f7f21a348ad1401660a50e8df1dc765cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_affa77b2bcedc0262632bafb6d83994f7f21a348ad1401660a50e8df1dc765cd->enter($__internal_affa77b2bcedc0262632bafb6d83994f7f21a348ad1401660a50e8df1dc765cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 36
        echo "<div class=\"input-group\">";
        // line 37
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 38
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_affa77b2bcedc0262632bafb6d83994f7f21a348ad1401660a50e8df1dc765cd->leave($__internal_affa77b2bcedc0262632bafb6d83994f7f21a348ad1401660a50e8df1dc765cd_prof);

        
        $__internal_bc685070c568b9992a09e7ddba23b8d716daa79c88542d616000753776db2490->leave($__internal_bc685070c568b9992a09e7ddba23b8d716daa79c88542d616000753776db2490_prof);

    }

    // line 42
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_9bb43e0709c80fad6ea46c3a6bda93344d93247817b3feb6cee9e1257522b414 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9bb43e0709c80fad6ea46c3a6bda93344d93247817b3feb6cee9e1257522b414->enter($__internal_9bb43e0709c80fad6ea46c3a6bda93344d93247817b3feb6cee9e1257522b414_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_a6567a9800f45bb0162a6e4e1aa2e1bcd45a8cdf891c1774cfdbb76ef2f17458 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6567a9800f45bb0162a6e4e1aa2e1bcd45a8cdf891c1774cfdbb76ef2f17458->enter($__internal_a6567a9800f45bb0162a6e4e1aa2e1bcd45a8cdf891c1774cfdbb76ef2f17458_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 43
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 44
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 46
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 47
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 48
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'errors');
            // line 49
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'errors');
            // line 50
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'widget', array("datetime" => true));
            // line 51
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'widget', array("datetime" => true));
            // line 52
            echo "</div>";
        }
        
        $__internal_a6567a9800f45bb0162a6e4e1aa2e1bcd45a8cdf891c1774cfdbb76ef2f17458->leave($__internal_a6567a9800f45bb0162a6e4e1aa2e1bcd45a8cdf891c1774cfdbb76ef2f17458_prof);

        
        $__internal_9bb43e0709c80fad6ea46c3a6bda93344d93247817b3feb6cee9e1257522b414->leave($__internal_9bb43e0709c80fad6ea46c3a6bda93344d93247817b3feb6cee9e1257522b414_prof);

    }

    // line 56
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_61d29a351a5c837793df856d63aa05227485300ed0cb2988b919bd01bd21751c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_61d29a351a5c837793df856d63aa05227485300ed0cb2988b919bd01bd21751c->enter($__internal_61d29a351a5c837793df856d63aa05227485300ed0cb2988b919bd01bd21751c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_0cc8b7cea43171e032d615f5a55b704744b48c208a93111c885599913c6cb760 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cc8b7cea43171e032d615f5a55b704744b48c208a93111c885599913c6cb760->enter($__internal_0cc8b7cea43171e032d615f5a55b704744b48c208a93111c885599913c6cb760_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 57
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 58
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 60
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 61
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 62
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 64
            echo twig_replace_filter(($context["date_pattern"] ?? $this->getContext($context, "date_pattern")), array("{{ year }}" =>             // line 65
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget'), "{{ month }}" =>             // line 66
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget'), "{{ day }}" =>             // line 67
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "day", array()), 'widget')));
            // line 69
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 70
                echo "</div>";
            }
        }
        
        $__internal_0cc8b7cea43171e032d615f5a55b704744b48c208a93111c885599913c6cb760->leave($__internal_0cc8b7cea43171e032d615f5a55b704744b48c208a93111c885599913c6cb760_prof);

        
        $__internal_61d29a351a5c837793df856d63aa05227485300ed0cb2988b919bd01bd21751c->leave($__internal_61d29a351a5c837793df856d63aa05227485300ed0cb2988b919bd01bd21751c_prof);

    }

    // line 75
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_4da16c574cc1cde6a8a99c1256bac0859cdefbe273692acee1b19d5b193024f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4da16c574cc1cde6a8a99c1256bac0859cdefbe273692acee1b19d5b193024f8->enter($__internal_4da16c574cc1cde6a8a99c1256bac0859cdefbe273692acee1b19d5b193024f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_77b3853555016dbfa82e18faa21ecc553acfec656cabd19c5bd0fc0f4fceafe1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77b3853555016dbfa82e18faa21ecc553acfec656cabd19c5bd0fc0f4fceafe1->enter($__internal_77b3853555016dbfa82e18faa21ecc553acfec656cabd19c5bd0fc0f4fceafe1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 76
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 77
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 79
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 80
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 81
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 83
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hour", array()), 'widget');
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minute", array()), 'widget');
            }
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "second", array()), 'widget');
            }
            // line 84
            echo "        ";
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 85
                echo "</div>";
            }
        }
        
        $__internal_77b3853555016dbfa82e18faa21ecc553acfec656cabd19c5bd0fc0f4fceafe1->leave($__internal_77b3853555016dbfa82e18faa21ecc553acfec656cabd19c5bd0fc0f4fceafe1_prof);

        
        $__internal_4da16c574cc1cde6a8a99c1256bac0859cdefbe273692acee1b19d5b193024f8->leave($__internal_4da16c574cc1cde6a8a99c1256bac0859cdefbe273692acee1b19d5b193024f8_prof);

    }

    // line 90
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_a77ecc3af7b9fa84af1052a004130568bab4076e0ea42c5af151c2648d4838b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a77ecc3af7b9fa84af1052a004130568bab4076e0ea42c5af151c2648d4838b6->enter($__internal_a77ecc3af7b9fa84af1052a004130568bab4076e0ea42c5af151c2648d4838b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_e08a228b414b8e86a02c45d0a33e0e67006caeabd7116e6e87f899cfc927a42e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e08a228b414b8e86a02c45d0a33e0e67006caeabd7116e6e87f899cfc927a42e->enter($__internal_e08a228b414b8e86a02c45d0a33e0e67006caeabd7116e6e87f899cfc927a42e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 91
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 92
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 94
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 95
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 96
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 97
            echo "<div class=\"table-responsive\">
                <table class=\"table ";
            // line 98
            echo twig_escape_filter($this->env, ((array_key_exists("table_class", $context)) ? (_twig_default_filter(($context["table_class"] ?? $this->getContext($context, "table_class")), "table-bordered table-condensed table-striped")) : ("table-bordered table-condensed table-striped")), "html", null, true);
            echo "\">
                    <thead>
                    <tr>";
            // line 101
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'label');
                echo "</th>";
            }
            // line 102
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'label');
                echo "</th>";
            }
            // line 103
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'label');
                echo "</th>";
            }
            // line 104
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'label');
                echo "</th>";
            }
            // line 105
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'label');
                echo "</th>";
            }
            // line 106
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'label');
                echo "</th>";
            }
            // line 107
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'label');
                echo "</th>";
            }
            // line 108
            echo "</tr>
                    </thead>
                    <tbody>
                    <tr>";
            // line 112
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'widget');
                echo "</td>";
            }
            // line 113
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'widget');
                echo "</td>";
            }
            // line 114
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'widget');
                echo "</td>";
            }
            // line 115
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'widget');
                echo "</td>";
            }
            // line 116
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'widget');
                echo "</td>";
            }
            // line 117
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'widget');
                echo "</td>";
            }
            // line 118
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'widget');
                echo "</td>";
            }
            // line 119
            echo "</tr>
                    </tbody>
                </table>
            </div>";
            // line 123
            if (($context["with_invert"] ?? $this->getContext($context, "with_invert"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "invert", array()), 'widget');
            }
            // line 124
            echo "</div>";
        }
        
        $__internal_e08a228b414b8e86a02c45d0a33e0e67006caeabd7116e6e87f899cfc927a42e->leave($__internal_e08a228b414b8e86a02c45d0a33e0e67006caeabd7116e6e87f899cfc927a42e_prof);

        
        $__internal_a77ecc3af7b9fa84af1052a004130568bab4076e0ea42c5af151c2648d4838b6->leave($__internal_a77ecc3af7b9fa84af1052a004130568bab4076e0ea42c5af151c2648d4838b6_prof);

    }

    // line 128
    public function block_choice_widget_collapsed($context, array $blocks = array())
    {
        $__internal_701e44e3876ddad82109cad27b696392909f2e9313383139fba9784e5606d256 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_701e44e3876ddad82109cad27b696392909f2e9313383139fba9784e5606d256->enter($__internal_701e44e3876ddad82109cad27b696392909f2e9313383139fba9784e5606d256_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        $__internal_9b7517842ccc6c5b675f9628d00495076da348b23335082759a22d0b633214fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b7517842ccc6c5b675f9628d00495076da348b23335082759a22d0b633214fa->enter($__internal_9b7517842ccc6c5b675f9628d00495076da348b23335082759a22d0b633214fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        // line 129
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 130
        $this->displayParentBlock("choice_widget_collapsed", $context, $blocks);
        
        $__internal_9b7517842ccc6c5b675f9628d00495076da348b23335082759a22d0b633214fa->leave($__internal_9b7517842ccc6c5b675f9628d00495076da348b23335082759a22d0b633214fa_prof);

        
        $__internal_701e44e3876ddad82109cad27b696392909f2e9313383139fba9784e5606d256->leave($__internal_701e44e3876ddad82109cad27b696392909f2e9313383139fba9784e5606d256_prof);

    }

    // line 133
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_bc289c8691693e69933e49ed717d605b2c5cb3a52a403740c12cc54f1d017a6c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc289c8691693e69933e49ed717d605b2c5cb3a52a403740c12cc54f1d017a6c->enter($__internal_bc289c8691693e69933e49ed717d605b2c5cb3a52a403740c12cc54f1d017a6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_e9b1641c82884371278d969e5534368f274ddbda7b99f7fd5d18f34149b16f24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9b1641c82884371278d969e5534368f274ddbda7b99f7fd5d18f34149b16f24->enter($__internal_e9b1641c82884371278d969e5534368f274ddbda7b99f7fd5d18f34149b16f24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 134
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 135
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 136
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 137
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 138
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 142
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 143
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 144
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 145
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 146
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 149
            echo "</div>";
        }
        
        $__internal_e9b1641c82884371278d969e5534368f274ddbda7b99f7fd5d18f34149b16f24->leave($__internal_e9b1641c82884371278d969e5534368f274ddbda7b99f7fd5d18f34149b16f24_prof);

        
        $__internal_bc289c8691693e69933e49ed717d605b2c5cb3a52a403740c12cc54f1d017a6c->leave($__internal_bc289c8691693e69933e49ed717d605b2c5cb3a52a403740c12cc54f1d017a6c_prof);

    }

    // line 153
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_d21705057cfd691364682ea4d916cb8f0b6d9ea3817dd198942bb241c036bbfc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d21705057cfd691364682ea4d916cb8f0b6d9ea3817dd198942bb241c036bbfc->enter($__internal_d21705057cfd691364682ea4d916cb8f0b6d9ea3817dd198942bb241c036bbfc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_069fba192c6eb2f32ca512e8eb10ff218dc5d6f9820f32a85784f05cce062079 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_069fba192c6eb2f32ca512e8eb10ff218dc5d6f9820f32a85784f05cce062079->enter($__internal_069fba192c6eb2f32ca512e8eb10ff218dc5d6f9820f32a85784f05cce062079_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 154
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 155
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 156
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 158
            echo "<div class=\"checkbox\">";
            // line 159
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 160
            echo "</div>";
        }
        
        $__internal_069fba192c6eb2f32ca512e8eb10ff218dc5d6f9820f32a85784f05cce062079->leave($__internal_069fba192c6eb2f32ca512e8eb10ff218dc5d6f9820f32a85784f05cce062079_prof);

        
        $__internal_d21705057cfd691364682ea4d916cb8f0b6d9ea3817dd198942bb241c036bbfc->leave($__internal_d21705057cfd691364682ea4d916cb8f0b6d9ea3817dd198942bb241c036bbfc_prof);

    }

    // line 164
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_caa7cd04b5f8e915b0d25b306e62d4b2aa4db4c0996b0f67d8f05e68b573463a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_caa7cd04b5f8e915b0d25b306e62d4b2aa4db4c0996b0f67d8f05e68b573463a->enter($__internal_caa7cd04b5f8e915b0d25b306e62d4b2aa4db4c0996b0f67d8f05e68b573463a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_8f9c20d74f87b91b96f714a1b78bef5d3ba5df4ba9c9eb3cbe8ce25c5abce207 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f9c20d74f87b91b96f714a1b78bef5d3ba5df4ba9c9eb3cbe8ce25c5abce207->enter($__internal_8f9c20d74f87b91b96f714a1b78bef5d3ba5df4ba9c9eb3cbe8ce25c5abce207_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 165
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 166
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 167
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 169
            echo "<div class=\"radio\">";
            // line 170
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 171
            echo "</div>";
        }
        
        $__internal_8f9c20d74f87b91b96f714a1b78bef5d3ba5df4ba9c9eb3cbe8ce25c5abce207->leave($__internal_8f9c20d74f87b91b96f714a1b78bef5d3ba5df4ba9c9eb3cbe8ce25c5abce207_prof);

        
        $__internal_caa7cd04b5f8e915b0d25b306e62d4b2aa4db4c0996b0f67d8f05e68b573463a->leave($__internal_caa7cd04b5f8e915b0d25b306e62d4b2aa4db4c0996b0f67d8f05e68b573463a_prof);

    }

    // line 177
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_d308330800f4a73f6dafd92c234b9ce6034be2ced8ea3c8568ab6646411b03c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d308330800f4a73f6dafd92c234b9ce6034be2ced8ea3c8568ab6646411b03c4->enter($__internal_d308330800f4a73f6dafd92c234b9ce6034be2ced8ea3c8568ab6646411b03c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_ae80819a84fb245ee4465c04803a8a15161d93fc977507700f308bc1d623fa31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae80819a84fb245ee4465c04803a8a15161d93fc977507700f308bc1d623fa31->enter($__internal_ae80819a84fb245ee4465c04803a8a15161d93fc977507700f308bc1d623fa31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 178
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " control-label"))));
        // line 179
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_ae80819a84fb245ee4465c04803a8a15161d93fc977507700f308bc1d623fa31->leave($__internal_ae80819a84fb245ee4465c04803a8a15161d93fc977507700f308bc1d623fa31_prof);

        
        $__internal_d308330800f4a73f6dafd92c234b9ce6034be2ced8ea3c8568ab6646411b03c4->leave($__internal_d308330800f4a73f6dafd92c234b9ce6034be2ced8ea3c8568ab6646411b03c4_prof);

    }

    // line 182
    public function block_choice_label($context, array $blocks = array())
    {
        $__internal_fe6aa514ca270dbddbf7a4e21d3e96a6aa05c1b6e528d087f5ecc6995391cb38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe6aa514ca270dbddbf7a4e21d3e96a6aa05c1b6e528d087f5ecc6995391cb38->enter($__internal_fe6aa514ca270dbddbf7a4e21d3e96a6aa05c1b6e528d087f5ecc6995391cb38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        $__internal_8d71f808bcf0af80fdf0f5df5d2aa7749283b6007e6f39b0d226aa18d3c85607 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d71f808bcf0af80fdf0f5df5d2aa7749283b6007e6f39b0d226aa18d3c85607->enter($__internal_8d71f808bcf0af80fdf0f5df5d2aa7749283b6007e6f39b0d226aa18d3c85607_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        // line 184
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(twig_replace_filter((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), array("checkbox-inline" => "", "radio-inline" => "")))));
        // line 185
        $this->displayBlock("form_label", $context, $blocks);
        
        $__internal_8d71f808bcf0af80fdf0f5df5d2aa7749283b6007e6f39b0d226aa18d3c85607->leave($__internal_8d71f808bcf0af80fdf0f5df5d2aa7749283b6007e6f39b0d226aa18d3c85607_prof);

        
        $__internal_fe6aa514ca270dbddbf7a4e21d3e96a6aa05c1b6e528d087f5ecc6995391cb38->leave($__internal_fe6aa514ca270dbddbf7a4e21d3e96a6aa05c1b6e528d087f5ecc6995391cb38_prof);

    }

    // line 188
    public function block_checkbox_label($context, array $blocks = array())
    {
        $__internal_c4c15b8ffe63b753ff33ddcec3818d5269e3056e5da1508ebc26db3d6e32a210 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4c15b8ffe63b753ff33ddcec3818d5269e3056e5da1508ebc26db3d6e32a210->enter($__internal_c4c15b8ffe63b753ff33ddcec3818d5269e3056e5da1508ebc26db3d6e32a210_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        $__internal_ad23dc579325ee33deb047938f34ac329ebbd6db5ff8ee8289027f022ea4ac9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad23dc579325ee33deb047938f34ac329ebbd6db5ff8ee8289027f022ea4ac9e->enter($__internal_ad23dc579325ee33deb047938f34ac329ebbd6db5ff8ee8289027f022ea4ac9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        // line 189
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 191
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_ad23dc579325ee33deb047938f34ac329ebbd6db5ff8ee8289027f022ea4ac9e->leave($__internal_ad23dc579325ee33deb047938f34ac329ebbd6db5ff8ee8289027f022ea4ac9e_prof);

        
        $__internal_c4c15b8ffe63b753ff33ddcec3818d5269e3056e5da1508ebc26db3d6e32a210->leave($__internal_c4c15b8ffe63b753ff33ddcec3818d5269e3056e5da1508ebc26db3d6e32a210_prof);

    }

    // line 194
    public function block_radio_label($context, array $blocks = array())
    {
        $__internal_78c27d0096dd281b949da02103d5d2156c9e8e892958ad4c64c35c7dbdce7f97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78c27d0096dd281b949da02103d5d2156c9e8e892958ad4c64c35c7dbdce7f97->enter($__internal_78c27d0096dd281b949da02103d5d2156c9e8e892958ad4c64c35c7dbdce7f97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        $__internal_4e52dcae7deca93a00b443943fbb5e9c1a1a9111daa117e6fa694b683f2815c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e52dcae7deca93a00b443943fbb5e9c1a1a9111daa117e6fa694b683f2815c7->enter($__internal_4e52dcae7deca93a00b443943fbb5e9c1a1a9111daa117e6fa694b683f2815c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        // line 195
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 197
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_4e52dcae7deca93a00b443943fbb5e9c1a1a9111daa117e6fa694b683f2815c7->leave($__internal_4e52dcae7deca93a00b443943fbb5e9c1a1a9111daa117e6fa694b683f2815c7_prof);

        
        $__internal_78c27d0096dd281b949da02103d5d2156c9e8e892958ad4c64c35c7dbdce7f97->leave($__internal_78c27d0096dd281b949da02103d5d2156c9e8e892958ad4c64c35c7dbdce7f97_prof);

    }

    // line 200
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_3fb7ed1a0ae5e156ce25d490be7c9fff411c8cf2a965433f7ff804719e5064d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3fb7ed1a0ae5e156ce25d490be7c9fff411c8cf2a965433f7ff804719e5064d9->enter($__internal_3fb7ed1a0ae5e156ce25d490be7c9fff411c8cf2a965433f7ff804719e5064d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_e88057ce0a1a48b61e99fe18e3c608529b22e7f6e7e756c7b183762ac3cb30ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e88057ce0a1a48b61e99fe18e3c608529b22e7f6e7e756c7b183762ac3cb30ce->enter($__internal_e88057ce0a1a48b61e99fe18e3c608529b22e7f6e7e756c7b183762ac3cb30ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 201
        echo "    ";
        // line 202
        echo "    ";
        if (array_key_exists("widget", $context)) {
            // line 203
            echo "        ";
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 204
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
                // line 205
                echo "        ";
            }
            // line 206
            echo "        ";
            if (array_key_exists("parent_label_class", $context)) {
                // line 207
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
                // line 208
                echo "        ";
            }
            // line 209
            echo "        ";
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 210
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 211
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 212
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 213
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 216
                    $context["label"] = $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 219
            echo "        <label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 220
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 221
            echo "</label>
    ";
        }
        
        $__internal_e88057ce0a1a48b61e99fe18e3c608529b22e7f6e7e756c7b183762ac3cb30ce->leave($__internal_e88057ce0a1a48b61e99fe18e3c608529b22e7f6e7e756c7b183762ac3cb30ce_prof);

        
        $__internal_3fb7ed1a0ae5e156ce25d490be7c9fff411c8cf2a965433f7ff804719e5064d9->leave($__internal_3fb7ed1a0ae5e156ce25d490be7c9fff411c8cf2a965433f7ff804719e5064d9_prof);

    }

    // line 227
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_8295277fc6abad6af29d98d9e16e4c12b8d16967592f1203d010c7c83e824834 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8295277fc6abad6af29d98d9e16e4c12b8d16967592f1203d010c7c83e824834->enter($__internal_8295277fc6abad6af29d98d9e16e4c12b8d16967592f1203d010c7c83e824834_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_d677e1f5beffa906ab1a1a92d3bce288c61e1d1034188c4f025e89d674bc5f8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d677e1f5beffa906ab1a1a92d3bce288c61e1d1034188c4f025e89d674bc5f8c->enter($__internal_d677e1f5beffa906ab1a1a92d3bce288c61e1d1034188c4f025e89d674bc5f8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 228
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 229
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 230
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 231
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 232
        echo "</div>";
        
        $__internal_d677e1f5beffa906ab1a1a92d3bce288c61e1d1034188c4f025e89d674bc5f8c->leave($__internal_d677e1f5beffa906ab1a1a92d3bce288c61e1d1034188c4f025e89d674bc5f8c_prof);

        
        $__internal_8295277fc6abad6af29d98d9e16e4c12b8d16967592f1203d010c7c83e824834->leave($__internal_8295277fc6abad6af29d98d9e16e4c12b8d16967592f1203d010c7c83e824834_prof);

    }

    // line 235
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_08e995bfffa8441493bdb9fac2ecc69f0b365ef4e086ae019bb0b1867084b470 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08e995bfffa8441493bdb9fac2ecc69f0b365ef4e086ae019bb0b1867084b470->enter($__internal_08e995bfffa8441493bdb9fac2ecc69f0b365ef4e086ae019bb0b1867084b470_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_b5704732c7a21c5aaf43de494c40b3c8643ce8c2b98ee84017111cdc73a5e19a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5704732c7a21c5aaf43de494c40b3c8643ce8c2b98ee84017111cdc73a5e19a->enter($__internal_b5704732c7a21c5aaf43de494c40b3c8643ce8c2b98ee84017111cdc73a5e19a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 236
        echo "<div class=\"form-group\">";
        // line 237
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 238
        echo "</div>";
        
        $__internal_b5704732c7a21c5aaf43de494c40b3c8643ce8c2b98ee84017111cdc73a5e19a->leave($__internal_b5704732c7a21c5aaf43de494c40b3c8643ce8c2b98ee84017111cdc73a5e19a_prof);

        
        $__internal_08e995bfffa8441493bdb9fac2ecc69f0b365ef4e086ae019bb0b1867084b470->leave($__internal_08e995bfffa8441493bdb9fac2ecc69f0b365ef4e086ae019bb0b1867084b470_prof);

    }

    // line 241
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_c98279028675ec9f396cdddafd4640be7188ffad5c21861b2366a6767cd49f1f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c98279028675ec9f396cdddafd4640be7188ffad5c21861b2366a6767cd49f1f->enter($__internal_c98279028675ec9f396cdddafd4640be7188ffad5c21861b2366a6767cd49f1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        $__internal_6eddd59cb058832f55915b331688fc457b8160122205518d6f0cd022e806d741 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6eddd59cb058832f55915b331688fc457b8160122205518d6f0cd022e806d741->enter($__internal_6eddd59cb058832f55915b331688fc457b8160122205518d6f0cd022e806d741_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 242
        $context["force_error"] = true;
        // line 243
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_6eddd59cb058832f55915b331688fc457b8160122205518d6f0cd022e806d741->leave($__internal_6eddd59cb058832f55915b331688fc457b8160122205518d6f0cd022e806d741_prof);

        
        $__internal_c98279028675ec9f396cdddafd4640be7188ffad5c21861b2366a6767cd49f1f->leave($__internal_c98279028675ec9f396cdddafd4640be7188ffad5c21861b2366a6767cd49f1f_prof);

    }

    // line 246
    public function block_date_row($context, array $blocks = array())
    {
        $__internal_7039491b136b45bdc295b27d3f3612590541e9796ab87b27fcdba6e4f6a2dfd3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7039491b136b45bdc295b27d3f3612590541e9796ab87b27fcdba6e4f6a2dfd3->enter($__internal_7039491b136b45bdc295b27d3f3612590541e9796ab87b27fcdba6e4f6a2dfd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        $__internal_d806ed26b6f34d162fc46fa7d8185f704b992b120ab232f9b7a7abfb9b7dcda8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d806ed26b6f34d162fc46fa7d8185f704b992b120ab232f9b7a7abfb9b7dcda8->enter($__internal_d806ed26b6f34d162fc46fa7d8185f704b992b120ab232f9b7a7abfb9b7dcda8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        // line 247
        $context["force_error"] = true;
        // line 248
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_d806ed26b6f34d162fc46fa7d8185f704b992b120ab232f9b7a7abfb9b7dcda8->leave($__internal_d806ed26b6f34d162fc46fa7d8185f704b992b120ab232f9b7a7abfb9b7dcda8_prof);

        
        $__internal_7039491b136b45bdc295b27d3f3612590541e9796ab87b27fcdba6e4f6a2dfd3->leave($__internal_7039491b136b45bdc295b27d3f3612590541e9796ab87b27fcdba6e4f6a2dfd3_prof);

    }

    // line 251
    public function block_time_row($context, array $blocks = array())
    {
        $__internal_8fffd6b3a2e964d8d29946a60163aeebe28c2220823ee7603b61e5835c311702 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fffd6b3a2e964d8d29946a60163aeebe28c2220823ee7603b61e5835c311702->enter($__internal_8fffd6b3a2e964d8d29946a60163aeebe28c2220823ee7603b61e5835c311702_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        $__internal_f847452b0806059c9743e1127ababe621d77519f63ed1744dcd670a1e3ed14e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f847452b0806059c9743e1127ababe621d77519f63ed1744dcd670a1e3ed14e4->enter($__internal_f847452b0806059c9743e1127ababe621d77519f63ed1744dcd670a1e3ed14e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        // line 252
        $context["force_error"] = true;
        // line 253
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_f847452b0806059c9743e1127ababe621d77519f63ed1744dcd670a1e3ed14e4->leave($__internal_f847452b0806059c9743e1127ababe621d77519f63ed1744dcd670a1e3ed14e4_prof);

        
        $__internal_8fffd6b3a2e964d8d29946a60163aeebe28c2220823ee7603b61e5835c311702->leave($__internal_8fffd6b3a2e964d8d29946a60163aeebe28c2220823ee7603b61e5835c311702_prof);

    }

    // line 256
    public function block_datetime_row($context, array $blocks = array())
    {
        $__internal_777feb8d269697ad4b887092da6e3b46e1485635d917cb077a3a014b2c875b8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_777feb8d269697ad4b887092da6e3b46e1485635d917cb077a3a014b2c875b8f->enter($__internal_777feb8d269697ad4b887092da6e3b46e1485635d917cb077a3a014b2c875b8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        $__internal_a21046348fdac398f9a587d136133d06ce8a5f405226353f79f223b4d7502c77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a21046348fdac398f9a587d136133d06ce8a5f405226353f79f223b4d7502c77->enter($__internal_a21046348fdac398f9a587d136133d06ce8a5f405226353f79f223b4d7502c77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        // line 257
        $context["force_error"] = true;
        // line 258
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_a21046348fdac398f9a587d136133d06ce8a5f405226353f79f223b4d7502c77->leave($__internal_a21046348fdac398f9a587d136133d06ce8a5f405226353f79f223b4d7502c77_prof);

        
        $__internal_777feb8d269697ad4b887092da6e3b46e1485635d917cb077a3a014b2c875b8f->leave($__internal_777feb8d269697ad4b887092da6e3b46e1485635d917cb077a3a014b2c875b8f_prof);

    }

    // line 261
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_a5400451c436ca0e72f999488beec9a7d6c677baa8a5da4166504592f5a68711 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5400451c436ca0e72f999488beec9a7d6c677baa8a5da4166504592f5a68711->enter($__internal_a5400451c436ca0e72f999488beec9a7d6c677baa8a5da4166504592f5a68711_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_53f8ec1354dfbb4bce5da13f0682303321965beb2b2a87898eb813a29a0e5d87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53f8ec1354dfbb4bce5da13f0682303321965beb2b2a87898eb813a29a0e5d87->enter($__internal_53f8ec1354dfbb4bce5da13f0682303321965beb2b2a87898eb813a29a0e5d87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 262
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 263
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 264
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 265
        echo "</div>";
        
        $__internal_53f8ec1354dfbb4bce5da13f0682303321965beb2b2a87898eb813a29a0e5d87->leave($__internal_53f8ec1354dfbb4bce5da13f0682303321965beb2b2a87898eb813a29a0e5d87_prof);

        
        $__internal_a5400451c436ca0e72f999488beec9a7d6c677baa8a5da4166504592f5a68711->leave($__internal_a5400451c436ca0e72f999488beec9a7d6c677baa8a5da4166504592f5a68711_prof);

    }

    // line 268
    public function block_radio_row($context, array $blocks = array())
    {
        $__internal_b00c106f3dd7b137c1343428487e69d8e6951ed54ca3b06a37aaaa2137e2e709 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b00c106f3dd7b137c1343428487e69d8e6951ed54ca3b06a37aaaa2137e2e709->enter($__internal_b00c106f3dd7b137c1343428487e69d8e6951ed54ca3b06a37aaaa2137e2e709_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        $__internal_f61a27c9355ec158d018718726097190511cc2ca34d7449faf95e453b36f44d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f61a27c9355ec158d018718726097190511cc2ca34d7449faf95e453b36f44d1->enter($__internal_f61a27c9355ec158d018718726097190511cc2ca34d7449faf95e453b36f44d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        // line 269
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 270
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 271
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 272
        echo "</div>";
        
        $__internal_f61a27c9355ec158d018718726097190511cc2ca34d7449faf95e453b36f44d1->leave($__internal_f61a27c9355ec158d018718726097190511cc2ca34d7449faf95e453b36f44d1_prof);

        
        $__internal_b00c106f3dd7b137c1343428487e69d8e6951ed54ca3b06a37aaaa2137e2e709->leave($__internal_b00c106f3dd7b137c1343428487e69d8e6951ed54ca3b06a37aaaa2137e2e709_prof);

    }

    // line 277
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_80bdf1b147aeba88796e5af49db4f7ac5d04cd911cccf027e164ae7b6453032c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_80bdf1b147aeba88796e5af49db4f7ac5d04cd911cccf027e164ae7b6453032c->enter($__internal_80bdf1b147aeba88796e5af49db4f7ac5d04cd911cccf027e164ae7b6453032c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_81fe92cf58624d7bcc277dcf09d91688a9b4dcfd046ba7504599fd326596e1fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81fe92cf58624d7bcc277dcf09d91688a9b4dcfd046ba7504599fd326596e1fd->enter($__internal_81fe92cf58624d7bcc277dcf09d91688a9b4dcfd046ba7504599fd326596e1fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 278
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 279
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 280
            echo "    <ul class=\"list-unstyled\">";
            // line 281
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 282
                echo "<li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 284
            echo "</ul>
    ";
            // line 285
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_81fe92cf58624d7bcc277dcf09d91688a9b4dcfd046ba7504599fd326596e1fd->leave($__internal_81fe92cf58624d7bcc277dcf09d91688a9b4dcfd046ba7504599fd326596e1fd_prof);

        
        $__internal_80bdf1b147aeba88796e5af49db4f7ac5d04cd911cccf027e164ae7b6453032c->leave($__internal_80bdf1b147aeba88796e5af49db4f7ac5d04cd911cccf027e164ae7b6453032c_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1139 => 285,  1136 => 284,  1128 => 282,  1124 => 281,  1122 => 280,  1116 => 279,  1114 => 278,  1105 => 277,  1095 => 272,  1093 => 271,  1091 => 270,  1085 => 269,  1076 => 268,  1066 => 265,  1064 => 264,  1062 => 263,  1056 => 262,  1047 => 261,  1037 => 258,  1035 => 257,  1026 => 256,  1016 => 253,  1014 => 252,  1005 => 251,  995 => 248,  993 => 247,  984 => 246,  974 => 243,  972 => 242,  963 => 241,  953 => 238,  951 => 237,  949 => 236,  940 => 235,  930 => 232,  928 => 231,  926 => 230,  924 => 229,  918 => 228,  909 => 227,  897 => 221,  893 => 220,  878 => 219,  874 => 216,  871 => 213,  870 => 212,  869 => 211,  867 => 210,  864 => 209,  861 => 208,  858 => 207,  855 => 206,  852 => 205,  849 => 204,  846 => 203,  843 => 202,  841 => 201,  832 => 200,  822 => 197,  820 => 195,  811 => 194,  801 => 191,  799 => 189,  790 => 188,  780 => 185,  778 => 184,  769 => 182,  759 => 179,  757 => 178,  748 => 177,  737 => 171,  735 => 170,  733 => 169,  730 => 167,  728 => 166,  726 => 165,  717 => 164,  706 => 160,  704 => 159,  702 => 158,  699 => 156,  697 => 155,  695 => 154,  686 => 153,  675 => 149,  669 => 146,  668 => 145,  667 => 144,  663 => 143,  659 => 142,  652 => 138,  651 => 137,  650 => 136,  646 => 135,  644 => 134,  635 => 133,  625 => 130,  623 => 129,  614 => 128,  603 => 124,  599 => 123,  594 => 119,  588 => 118,  582 => 117,  576 => 116,  570 => 115,  564 => 114,  558 => 113,  552 => 112,  547 => 108,  541 => 107,  535 => 106,  529 => 105,  523 => 104,  517 => 103,  511 => 102,  505 => 101,  500 => 98,  497 => 97,  495 => 96,  491 => 95,  489 => 94,  486 => 92,  484 => 91,  475 => 90,  463 => 85,  460 => 84,  450 => 83,  445 => 81,  443 => 80,  441 => 79,  438 => 77,  436 => 76,  427 => 75,  415 => 70,  413 => 69,  411 => 67,  410 => 66,  409 => 65,  408 => 64,  403 => 62,  401 => 61,  399 => 60,  396 => 58,  394 => 57,  385 => 56,  374 => 52,  372 => 51,  370 => 50,  368 => 49,  366 => 48,  362 => 47,  360 => 46,  357 => 44,  355 => 43,  346 => 42,  335 => 38,  333 => 37,  331 => 36,  322 => 35,  312 => 32,  306 => 30,  304 => 29,  302 => 28,  296 => 26,  293 => 25,  291 => 24,  288 => 23,  279 => 22,  269 => 19,  267 => 18,  258 => 17,  248 => 14,  246 => 13,  237 => 12,  227 => 9,  224 => 7,  222 => 6,  213 => 5,  203 => 277,  200 => 276,  197 => 274,  195 => 268,  192 => 267,  190 => 261,  187 => 260,  185 => 256,  182 => 255,  180 => 251,  177 => 250,  175 => 246,  172 => 245,  170 => 241,  167 => 240,  165 => 235,  162 => 234,  160 => 227,  157 => 226,  154 => 224,  152 => 200,  149 => 199,  147 => 194,  144 => 193,  142 => 188,  139 => 187,  137 => 182,  134 => 181,  132 => 177,  129 => 176,  126 => 174,  124 => 164,  121 => 163,  119 => 153,  116 => 152,  114 => 133,  111 => 132,  109 => 128,  107 => 90,  105 => 75,  102 => 74,  100 => 56,  97 => 55,  95 => 42,  92 => 41,  90 => 35,  87 => 34,  85 => 22,  82 => 21,  80 => 17,  77 => 16,  75 => 12,  72 => 11,  70 => 5,  67 => 4,  64 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{# Widgets #}

{% block form_widget_simple -%}
    {% if type is not defined or type not in ['file', 'hidden'] %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{% block textarea_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock textarea_widget %}

{% block button_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('btn-default') ~ ' btn')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block money_widget -%}
    <div class=\"input-group\">
        {% set append = money_pattern starts with '{{' %}
        {% if not append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
        {{- block('form_widget_simple') -}}
        {% if append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
    </div>
{%- endblock money_widget %}

{% block percent_widget -%}
    <div class=\"input-group\">
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block datetime_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form.date) -}}
            {{- form_errors(form.time) -}}
            {{- form_widget(form.date, { datetime: true } ) -}}
            {{- form_widget(form.time, { datetime: true } ) -}}
        </div>
    {%- endif %}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or not datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif %}
            {{- date_pattern|replace({
                '{{ year }}': form_widget(form.year),
                '{{ month }}': form_widget(form.month),
                '{{ day }}': form_widget(form.day),
            })|raw -}}
        {% if datetime is not defined or not datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock date_widget %}

{% block time_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or false == datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif -%}
        {{- form_widget(form.hour) }}{% if with_minutes %}:{{ form_widget(form.minute) }}{% endif %}{% if with_seconds %}:{{ form_widget(form.second) }}{% endif %}
        {% if datetime is not defined or false == datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock time_widget %}

{%- block dateinterval_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form) -}}
            <div class=\"table-responsive\">
                <table class=\"table {{ table_class|default('table-bordered table-condensed table-striped') }}\">
                    <thead>
                    <tr>
                        {%- if with_years %}<th>{{ form_label(form.years) }}</th>{% endif -%}
                        {%- if with_months %}<th>{{ form_label(form.months) }}</th>{% endif -%}
                        {%- if with_weeks %}<th>{{ form_label(form.weeks) }}</th>{% endif -%}
                        {%- if with_days %}<th>{{ form_label(form.days) }}</th>{% endif -%}
                        {%- if with_hours %}<th>{{ form_label(form.hours) }}</th>{% endif -%}
                        {%- if with_minutes %}<th>{{ form_label(form.minutes) }}</th>{% endif -%}
                        {%- if with_seconds %}<th>{{ form_label(form.seconds) }}</th>{% endif -%}
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        {%- if with_years %}<td>{{ form_widget(form.years) }}</td>{% endif -%}
                        {%- if with_months %}<td>{{ form_widget(form.months) }}</td>{% endif -%}
                        {%- if with_weeks %}<td>{{ form_widget(form.weeks) }}</td>{% endif -%}
                        {%- if with_days %}<td>{{ form_widget(form.days) }}</td>{% endif -%}
                        {%- if with_hours %}<td>{{ form_widget(form.hours) }}</td>{% endif -%}
                        {%- if with_minutes %}<td>{{ form_widget(form.minutes) }}</td>{% endif -%}
                        {%- if with_seconds %}<td>{{ form_widget(form.seconds) }}</td>{% endif -%}
                    </tr>
                    </tbody>
                </table>
            </div>
            {%- if with_invert %}{{ form_widget(form.invert) }}{% endif -%}
        </div>
    {%- endif -%}
{%- endblock dateinterval_widget -%}

{% block choice_widget_collapsed -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block choice_widget_expanded -%}
    {% if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
            }) -}}
        {% endfor -%}
    {%- else -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                }) -}}
            {% endfor -%}
        </div>
    {%- endif %}
{%- endblock choice_widget_expanded %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"checkbox\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'radio-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"radio\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock radio_widget %}

{# Labels #}

{% block form_label -%}
    {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' control-label')|trim}) -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block choice_label -%}
    {# remove the checkbox-inline and radio-inline class, it's only useful for embed labels #}
    {%- set label_attr = label_attr|merge({class: label_attr.class|default('')|replace({'checkbox-inline': '', 'radio-inline': ''})|trim}) -%}
    {{- block('form_label') -}}
{% endblock %}

{% block checkbox_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock checkbox_label %}

{% block radio_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock radio_label %}

{% block checkbox_radio_label %}
    {# Do not display the label if widget is not defined in order to prevent double label rendering #}
    {% if widget is defined %}
        {% if required %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) %}
        {% endif %}
        {% if parent_label_class is defined %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) %}
        {% endif %}
        {% if label is not same as(false) and label is empty %}
            {%- if label_format is not empty -%}
                {% set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) %}
            {%- else -%}
                {% set label = name|humanize %}
            {%- endif -%}
        {% endif %}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {% endif %}
{% endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock form_row %}

{% block button_row -%}
    <div class=\"form-group\">
        {{- form_widget(form) -}}
    </div>
{%- endblock button_row %}

{% block choice_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock choice_row %}

{% block date_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock date_row %}

{% block time_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock time_row %}

{% block datetime_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock datetime_row %}

{% block checkbox_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock checkbox_row %}

{% block radio_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock radio_row %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
    {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
    <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            <li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> {{ error.message }}</li>
        {%- endfor -%}
    </ul>
    {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_3_layout.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_3_layout.html.twig");
    }
}
