<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_9b78c2e11f0015f10c9f2c54750a647ab7019c6656e5ee17d23edc8d63415a05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_43c6e4545bb52b37c5a20c9db0a36610643773cf20d8b5390d2edc394a77707f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_43c6e4545bb52b37c5a20c9db0a36610643773cf20d8b5390d2edc394a77707f->enter($__internal_43c6e4545bb52b37c5a20c9db0a36610643773cf20d8b5390d2edc394a77707f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_324c1771dcae4289052561b338af495e4e6d1cc191ecbccd3f7484ff8a88efac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_324c1771dcae4289052561b338af495e4e6d1cc191ecbccd3f7484ff8a88efac->enter($__internal_324c1771dcae4289052561b338af495e4e6d1cc191ecbccd3f7484ff8a88efac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_43c6e4545bb52b37c5a20c9db0a36610643773cf20d8b5390d2edc394a77707f->leave($__internal_43c6e4545bb52b37c5a20c9db0a36610643773cf20d8b5390d2edc394a77707f_prof);

        
        $__internal_324c1771dcae4289052561b338af495e4e6d1cc191ecbccd3f7484ff8a88efac->leave($__internal_324c1771dcae4289052561b338af495e4e6d1cc191ecbccd3f7484ff8a88efac_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.rdf.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.rdf.twig");
    }
}
