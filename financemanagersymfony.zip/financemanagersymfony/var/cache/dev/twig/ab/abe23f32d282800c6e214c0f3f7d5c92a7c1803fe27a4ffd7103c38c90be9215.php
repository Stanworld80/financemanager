<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_5f7dd656d3b0a26f34e8c8b8dc3cf6a12151d8a3be12a50af7600d6681901dbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7dd85c4cd3bb140d58817e8e215469d6dbb7b10740ff312a22eaa2fc6cf5128 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7dd85c4cd3bb140d58817e8e215469d6dbb7b10740ff312a22eaa2fc6cf5128->enter($__internal_e7dd85c4cd3bb140d58817e8e215469d6dbb7b10740ff312a22eaa2fc6cf5128_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_5938da5b085a862979c51246e900ea6975c334e760a06a20222e0d6f5356b187 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5938da5b085a862979c51246e900ea6975c334e760a06a20222e0d6f5356b187->enter($__internal_5938da5b085a862979c51246e900ea6975c334e760a06a20222e0d6f5356b187_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_e7dd85c4cd3bb140d58817e8e215469d6dbb7b10740ff312a22eaa2fc6cf5128->leave($__internal_e7dd85c4cd3bb140d58817e8e215469d6dbb7b10740ff312a22eaa2fc6cf5128_prof);

        
        $__internal_5938da5b085a862979c51246e900ea6975c334e760a06a20222e0d6f5356b187->leave($__internal_5938da5b085a862979c51246e900ea6975c334e760a06a20222e0d6f5356b187_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.js.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
