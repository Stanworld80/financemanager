<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_dc0f8ae5e05c9971c5f64207ea7dc37af6e4a6722d174c02ebbfa97d57123f3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03d75e57fe0d370b93d90a378dba1ce15532241f66b770426062d808b0b00de2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03d75e57fe0d370b93d90a378dba1ce15532241f66b770426062d808b0b00de2->enter($__internal_03d75e57fe0d370b93d90a378dba1ce15532241f66b770426062d808b0b00de2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_dae1a5044b69bbe9d25c935608c72342fdc9beed924fbbb552b88648323e9e04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dae1a5044b69bbe9d25c935608c72342fdc9beed924fbbb552b88648323e9e04->enter($__internal_dae1a5044b69bbe9d25c935608c72342fdc9beed924fbbb552b88648323e9e04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_03d75e57fe0d370b93d90a378dba1ce15532241f66b770426062d808b0b00de2->leave($__internal_03d75e57fe0d370b93d90a378dba1ce15532241f66b770426062d808b0b00de2_prof);

        
        $__internal_dae1a5044b69bbe9d25c935608c72342fdc9beed924fbbb552b88648323e9e04->leave($__internal_dae1a5044b69bbe9d25c935608c72342fdc9beed924fbbb552b88648323e9e04_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_6cbe6ac54d410b7ab464975c8ab7c7d4dde77601185d63886337fa63dcab358e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cbe6ac54d410b7ab464975c8ab7c7d4dde77601185d63886337fa63dcab358e->enter($__internal_6cbe6ac54d410b7ab464975c8ab7c7d4dde77601185d63886337fa63dcab358e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ecee9497eb4b9b5d780fbcf2d4c5fd4ebe6818cc365d128a65574ebad855a31a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ecee9497eb4b9b5d780fbcf2d4c5fd4ebe6818cc365d128a65574ebad855a31a->enter($__internal_ecee9497eb4b9b5d780fbcf2d4c5fd4ebe6818cc365d128a65574ebad855a31a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_ecee9497eb4b9b5d780fbcf2d4c5fd4ebe6818cc365d128a65574ebad855a31a->leave($__internal_ecee9497eb4b9b5d780fbcf2d4c5fd4ebe6818cc365d128a65574ebad855a31a_prof);

        
        $__internal_6cbe6ac54d410b7ab464975c8ab7c7d4dde77601185d63886337fa63dcab358e->leave($__internal_6cbe6ac54d410b7ab464975c8ab7c7d4dde77601185d63886337fa63dcab358e_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_6bb89c63dded6eea95ae4e72f401456daa9ae1a520d5d0de2c79abaec5f05e7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6bb89c63dded6eea95ae4e72f401456daa9ae1a520d5d0de2c79abaec5f05e7a->enter($__internal_6bb89c63dded6eea95ae4e72f401456daa9ae1a520d5d0de2c79abaec5f05e7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d14e5117b673e60df26b7f549179669db5ae8b48031e02204f3e4af868f60e85 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d14e5117b673e60df26b7f549179669db5ae8b48031e02204f3e4af868f60e85->enter($__internal_d14e5117b673e60df26b7f549179669db5ae8b48031e02204f3e4af868f60e85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_d14e5117b673e60df26b7f549179669db5ae8b48031e02204f3e4af868f60e85->leave($__internal_d14e5117b673e60df26b7f549179669db5ae8b48031e02204f3e4af868f60e85_prof);

        
        $__internal_6bb89c63dded6eea95ae4e72f401456daa9ae1a520d5d0de2c79abaec5f05e7a->leave($__internal_6bb89c63dded6eea95ae4e72f401456daa9ae1a520d5d0de2c79abaec5f05e7a_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
