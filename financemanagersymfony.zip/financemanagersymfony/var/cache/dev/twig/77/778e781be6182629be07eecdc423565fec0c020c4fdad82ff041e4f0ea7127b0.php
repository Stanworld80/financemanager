<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_f711d2bf44b4853f4cf69b1c3609f704b154f3c4f69e4c9e0e50d4ffca88e2ed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3232db476d2370e7aa806ef0b659b64535312feb15e6b1d3db4d2330b7e798e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3232db476d2370e7aa806ef0b659b64535312feb15e6b1d3db4d2330b7e798e5->enter($__internal_3232db476d2370e7aa806ef0b659b64535312feb15e6b1d3db4d2330b7e798e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_3fe7f9daa2f3cff9025e61dd03c70ca90756b2329bdf0bc5cedb3f4b25f72095 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fe7f9daa2f3cff9025e61dd03c70ca90756b2329bdf0bc5cedb3f4b25f72095->enter($__internal_3fe7f9daa2f3cff9025e61dd03c70ca90756b2329bdf0bc5cedb3f4b25f72095_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_3232db476d2370e7aa806ef0b659b64535312feb15e6b1d3db4d2330b7e798e5->leave($__internal_3232db476d2370e7aa806ef0b659b64535312feb15e6b1d3db4d2330b7e798e5_prof);

        
        $__internal_3fe7f9daa2f3cff9025e61dd03c70ca90756b2329bdf0bc5cedb3f4b25f72095->leave($__internal_3fe7f9daa2f3cff9025e61dd03c70ca90756b2329bdf0bc5cedb3f4b25f72095_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\repeated_row.html.php");
    }
}
