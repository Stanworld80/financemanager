<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_e1b17b672d538b6b91c8a060c36b7e27608c889b2144a6a4e8ee4ce83b0f1b9d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2386691edefc7adc7a9c8921563db85f5232284d5af8a4957da373fc472f72f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2386691edefc7adc7a9c8921563db85f5232284d5af8a4957da373fc472f72f7->enter($__internal_2386691edefc7adc7a9c8921563db85f5232284d5af8a4957da373fc472f72f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_ba7b60eafd3c0183fed91995e6efab1cf30fb96a5b6e1d7bc53cdba83bd11aba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba7b60eafd3c0183fed91995e6efab1cf30fb96a5b6e1d7bc53cdba83bd11aba->enter($__internal_ba7b60eafd3c0183fed91995e6efab1cf30fb96a5b6e1d7bc53cdba83bd11aba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_2386691edefc7adc7a9c8921563db85f5232284d5af8a4957da373fc472f72f7->leave($__internal_2386691edefc7adc7a9c8921563db85f5232284d5af8a4957da373fc472f72f7_prof);

        
        $__internal_ba7b60eafd3c0183fed91995e6efab1cf30fb96a5b6e1d7bc53cdba83bd11aba->leave($__internal_ba7b60eafd3c0183fed91995e6efab1cf30fb96a5b6e1d7bc53cdba83bd11aba_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
