<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_91b4b33a8d56ac8295cc0d637773a2d242d2b31d62b769568e0934ddb51eb391 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d251fdb1c594fbb997b9da7e10468d4f372c5fe1ac44f134d520b71c85c4d955 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d251fdb1c594fbb997b9da7e10468d4f372c5fe1ac44f134d520b71c85c4d955->enter($__internal_d251fdb1c594fbb997b9da7e10468d4f372c5fe1ac44f134d520b71c85c4d955_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_5095f965690ce2227b93f273bf6800ec4e8a0923eb896dfff9c0a9e065e310ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5095f965690ce2227b93f273bf6800ec4e8a0923eb896dfff9c0a9e065e310ad->enter($__internal_5095f965690ce2227b93f273bf6800ec4e8a0923eb896dfff9c0a9e065e310ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_d251fdb1c594fbb997b9da7e10468d4f372c5fe1ac44f134d520b71c85c4d955->leave($__internal_d251fdb1c594fbb997b9da7e10468d4f372c5fe1ac44f134d520b71c85c4d955_prof);

        
        $__internal_5095f965690ce2227b93f273bf6800ec4e8a0923eb896dfff9c0a9e065e310ad->leave($__internal_5095f965690ce2227b93f273bf6800ec4e8a0923eb896dfff9c0a9e065e310ad_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
