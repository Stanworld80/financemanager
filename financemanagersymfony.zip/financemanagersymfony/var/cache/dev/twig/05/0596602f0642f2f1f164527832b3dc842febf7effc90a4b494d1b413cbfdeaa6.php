<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_e12506caa6aa0b489a5a6e3aed6a7d8b525d78ffcaed02e7eb56bb15cc405767 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd452ffde891c64a647213c1d619f34dc5135e890962d7701c301510dbeb1ee8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd452ffde891c64a647213c1d619f34dc5135e890962d7701c301510dbeb1ee8->enter($__internal_fd452ffde891c64a647213c1d619f34dc5135e890962d7701c301510dbeb1ee8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_e7d444642ac1df760a61a538cdbaf5ad51ddbb59ca0332101b9c566e3e1a65de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7d444642ac1df760a61a538cdbaf5ad51ddbb59ca0332101b9c566e3e1a65de->enter($__internal_e7d444642ac1df760a61a538cdbaf5ad51ddbb59ca0332101b9c566e3e1a65de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fd452ffde891c64a647213c1d619f34dc5135e890962d7701c301510dbeb1ee8->leave($__internal_fd452ffde891c64a647213c1d619f34dc5135e890962d7701c301510dbeb1ee8_prof);

        
        $__internal_e7d444642ac1df760a61a538cdbaf5ad51ddbb59ca0332101b9c566e3e1a65de->leave($__internal_e7d444642ac1df760a61a538cdbaf5ad51ddbb59ca0332101b9c566e3e1a65de_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_13577356b90076a6fbe17909638b007c9e2cab334dce18bc7f82a4e2d156efdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13577356b90076a6fbe17909638b007c9e2cab334dce18bc7f82a4e2d156efdd->enter($__internal_13577356b90076a6fbe17909638b007c9e2cab334dce18bc7f82a4e2d156efdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_70e0386a5d00fc2a16f37be9758b6c92182c5858bb5facc4999999a79ce841e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70e0386a5d00fc2a16f37be9758b6c92182c5858bb5facc4999999a79ce841e7->enter($__internal_70e0386a5d00fc2a16f37be9758b6c92182c5858bb5facc4999999a79ce841e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_70e0386a5d00fc2a16f37be9758b6c92182c5858bb5facc4999999a79ce841e7->leave($__internal_70e0386a5d00fc2a16f37be9758b6c92182c5858bb5facc4999999a79ce841e7_prof);

        
        $__internal_13577356b90076a6fbe17909638b007c9e2cab334dce18bc7f82a4e2d156efdd->leave($__internal_13577356b90076a6fbe17909638b007c9e2cab334dce18bc7f82a4e2d156efdd_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e7b3c2413846d50d9a2bcea6cf3deec970c43cede6cabe8da01829694bb1f364 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7b3c2413846d50d9a2bcea6cf3deec970c43cede6cabe8da01829694bb1f364->enter($__internal_e7b3c2413846d50d9a2bcea6cf3deec970c43cede6cabe8da01829694bb1f364_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0f6d29b15264e681d88a8f04dcc5f11637fb0f9f8e7d4ae0916d342a5e1750de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f6d29b15264e681d88a8f04dcc5f11637fb0f9f8e7d4ae0916d342a5e1750de->enter($__internal_0f6d29b15264e681d88a8f04dcc5f11637fb0f9f8e7d4ae0916d342a5e1750de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_0f6d29b15264e681d88a8f04dcc5f11637fb0f9f8e7d4ae0916d342a5e1750de->leave($__internal_0f6d29b15264e681d88a8f04dcc5f11637fb0f9f8e7d4ae0916d342a5e1750de_prof);

        
        $__internal_e7b3c2413846d50d9a2bcea6cf3deec970c43cede6cabe8da01829694bb1f364->leave($__internal_e7b3c2413846d50d9a2bcea6cf3deec970c43cede6cabe8da01829694bb1f364_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_3481cb5a2546c5bddcdb03698f25efb02f3503409f8f4b7e4a0a001bff32f122 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3481cb5a2546c5bddcdb03698f25efb02f3503409f8f4b7e4a0a001bff32f122->enter($__internal_3481cb5a2546c5bddcdb03698f25efb02f3503409f8f4b7e4a0a001bff32f122_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_e23cdabaa8857e85828eb54b933a497bee765c8863e4860625ec2c75ca7b0a1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e23cdabaa8857e85828eb54b933a497bee765c8863e4860625ec2c75ca7b0a1f->enter($__internal_e23cdabaa8857e85828eb54b933a497bee765c8863e4860625ec2c75ca7b0a1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_e23cdabaa8857e85828eb54b933a497bee765c8863e4860625ec2c75ca7b0a1f->leave($__internal_e23cdabaa8857e85828eb54b933a497bee765c8863e4860625ec2c75ca7b0a1f_prof);

        
        $__internal_3481cb5a2546c5bddcdb03698f25efb02f3503409f8f4b7e4a0a001bff32f122->leave($__internal_3481cb5a2546c5bddcdb03698f25efb02f3503409f8f4b7e4a0a001bff32f122_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
