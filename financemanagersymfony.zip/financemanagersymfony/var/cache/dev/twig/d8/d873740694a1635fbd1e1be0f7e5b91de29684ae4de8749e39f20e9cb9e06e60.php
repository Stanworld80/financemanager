<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_92831d4470acc03589f641d1084c9a5ed6caf834ae7038dfb2a16299d317f7e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb8e44a0203276b400b27ff182453a012ab9f2d0864821676e41d10c0a684472 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb8e44a0203276b400b27ff182453a012ab9f2d0864821676e41d10c0a684472->enter($__internal_bb8e44a0203276b400b27ff182453a012ab9f2d0864821676e41d10c0a684472_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_df1f8a8795e97ae6e9856dfcfbd8d046e14adbe69b3c00dd6af8a5b39c5d36ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df1f8a8795e97ae6e9856dfcfbd8d046e14adbe69b3c00dd6af8a5b39c5d36ad->enter($__internal_df1f8a8795e97ae6e9856dfcfbd8d046e14adbe69b3c00dd6af8a5b39c5d36ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_bb8e44a0203276b400b27ff182453a012ab9f2d0864821676e41d10c0a684472->leave($__internal_bb8e44a0203276b400b27ff182453a012ab9f2d0864821676e41d10c0a684472_prof);

        
        $__internal_df1f8a8795e97ae6e9856dfcfbd8d046e14adbe69b3c00dd6af8a5b39c5d36ad->leave($__internal_df1f8a8795e97ae6e9856dfcfbd8d046e14adbe69b3c00dd6af8a5b39c5d36ad_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget.html.php");
    }
}
