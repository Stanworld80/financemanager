<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_63ee2cb00a14a96d8b8e2f8ed7058e4a3d3c86fca6b4a15b07a0881d3af6047b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef5707fcb16953d08fdd33583f61523e6552066cfa8c89398f50d63787d6c5b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ef5707fcb16953d08fdd33583f61523e6552066cfa8c89398f50d63787d6c5b5->enter($__internal_ef5707fcb16953d08fdd33583f61523e6552066cfa8c89398f50d63787d6c5b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_50a109306b1ca931ded6f0433cdc874f2561411949b1eac0c3fb6cc309a2ef29 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50a109306b1ca931ded6f0433cdc874f2561411949b1eac0c3fb6cc309a2ef29->enter($__internal_50a109306b1ca931ded6f0433cdc874f2561411949b1eac0c3fb6cc309a2ef29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ef5707fcb16953d08fdd33583f61523e6552066cfa8c89398f50d63787d6c5b5->leave($__internal_ef5707fcb16953d08fdd33583f61523e6552066cfa8c89398f50d63787d6c5b5_prof);

        
        $__internal_50a109306b1ca931ded6f0433cdc874f2561411949b1eac0c3fb6cc309a2ef29->leave($__internal_50a109306b1ca931ded6f0433cdc874f2561411949b1eac0c3fb6cc309a2ef29_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_5f948d8ad2e49ed01d9b7217b40d26a3003240ce20c216091d147ceb9c7cf12b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f948d8ad2e49ed01d9b7217b40d26a3003240ce20c216091d147ceb9c7cf12b->enter($__internal_5f948d8ad2e49ed01d9b7217b40d26a3003240ce20c216091d147ceb9c7cf12b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f1202ce7819838acf20677357511d7375a4f683669e8bb8eba8d67739593b657 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1202ce7819838acf20677357511d7375a4f683669e8bb8eba8d67739593b657->enter($__internal_f1202ce7819838acf20677357511d7375a4f683669e8bb8eba8d67739593b657_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f1202ce7819838acf20677357511d7375a4f683669e8bb8eba8d67739593b657->leave($__internal_f1202ce7819838acf20677357511d7375a4f683669e8bb8eba8d67739593b657_prof);

        
        $__internal_5f948d8ad2e49ed01d9b7217b40d26a3003240ce20c216091d147ceb9c7cf12b->leave($__internal_5f948d8ad2e49ed01d9b7217b40d26a3003240ce20c216091d147ceb9c7cf12b_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ec67acdd3a426a732ed70a1e1f36f58761de0d8ccf7d2f7a257468e601680e5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec67acdd3a426a732ed70a1e1f36f58761de0d8ccf7d2f7a257468e601680e5a->enter($__internal_ec67acdd3a426a732ed70a1e1f36f58761de0d8ccf7d2f7a257468e601680e5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d8ce0742f2a027fa990db2849002ccda1355ab3877f42b2a0b1b2a02b9774d4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8ce0742f2a027fa990db2849002ccda1355ab3877f42b2a0b1b2a02b9774d4d->enter($__internal_d8ce0742f2a027fa990db2849002ccda1355ab3877f42b2a0b1b2a02b9774d4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_d8ce0742f2a027fa990db2849002ccda1355ab3877f42b2a0b1b2a02b9774d4d->leave($__internal_d8ce0742f2a027fa990db2849002ccda1355ab3877f42b2a0b1b2a02b9774d4d_prof);

        
        $__internal_ec67acdd3a426a732ed70a1e1f36f58761de0d8ccf7d2f7a257468e601680e5a->leave($__internal_ec67acdd3a426a732ed70a1e1f36f58761de0d8ccf7d2f7a257468e601680e5a_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_323ae373219ec7ed70cd51280f8970fb3f7dfbc98cd4f2e0d56e31c9bf183740 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_323ae373219ec7ed70cd51280f8970fb3f7dfbc98cd4f2e0d56e31c9bf183740->enter($__internal_323ae373219ec7ed70cd51280f8970fb3f7dfbc98cd4f2e0d56e31c9bf183740_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_d757709ac9a11bbe2aca35b46a8f90af3d15f472348d9d0f3bbb97918188dbff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d757709ac9a11bbe2aca35b46a8f90af3d15f472348d9d0f3bbb97918188dbff->enter($__internal_d757709ac9a11bbe2aca35b46a8f90af3d15f472348d9d0f3bbb97918188dbff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_d757709ac9a11bbe2aca35b46a8f90af3d15f472348d9d0f3bbb97918188dbff->leave($__internal_d757709ac9a11bbe2aca35b46a8f90af3d15f472348d9d0f3bbb97918188dbff_prof);

        
        $__internal_323ae373219ec7ed70cd51280f8970fb3f7dfbc98cd4f2e0d56e31c9bf183740->leave($__internal_323ae373219ec7ed70cd51280f8970fb3f7dfbc98cd4f2e0d56e31c9bf183740_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
