<?php

/* WebProfilerBundle:Collector:exception.html.twig */
class __TwigTemplate_725548b338eedc6c46ee3de02a8aa95131ead8954a4e2422c00f4878513a43ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4dd0195b26f1baa50c02ea946b958f93d678712ab2129b7719fd94b00d6453e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4dd0195b26f1baa50c02ea946b958f93d678712ab2129b7719fd94b00d6453e5->enter($__internal_4dd0195b26f1baa50c02ea946b958f93d678712ab2129b7719fd94b00d6453e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $__internal_86fd1f76d81b69cf97b8cc19b9511e2f14352eee81d944805fda826dfd119ffd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86fd1f76d81b69cf97b8cc19b9511e2f14352eee81d944805fda826dfd119ffd->enter($__internal_86fd1f76d81b69cf97b8cc19b9511e2f14352eee81d944805fda826dfd119ffd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4dd0195b26f1baa50c02ea946b958f93d678712ab2129b7719fd94b00d6453e5->leave($__internal_4dd0195b26f1baa50c02ea946b958f93d678712ab2129b7719fd94b00d6453e5_prof);

        
        $__internal_86fd1f76d81b69cf97b8cc19b9511e2f14352eee81d944805fda826dfd119ffd->leave($__internal_86fd1f76d81b69cf97b8cc19b9511e2f14352eee81d944805fda826dfd119ffd_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_2e33eff454990a28af5f34ea6e5e66410e41558519ec6b6ff1efae7981c0ab31 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e33eff454990a28af5f34ea6e5e66410e41558519ec6b6ff1efae7981c0ab31->enter($__internal_2e33eff454990a28af5f34ea6e5e66410e41558519ec6b6ff1efae7981c0ab31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_1936277d1ffa63072d5f6069f000f3eb22c19ad453c4419c47c746e63807add6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1936277d1ffa63072d5f6069f000f3eb22c19ad453c4419c47c746e63807add6->enter($__internal_1936277d1ffa63072d5f6069f000f3eb22c19ad453c4419c47c746e63807add6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_1936277d1ffa63072d5f6069f000f3eb22c19ad453c4419c47c746e63807add6->leave($__internal_1936277d1ffa63072d5f6069f000f3eb22c19ad453c4419c47c746e63807add6_prof);

        
        $__internal_2e33eff454990a28af5f34ea6e5e66410e41558519ec6b6ff1efae7981c0ab31->leave($__internal_2e33eff454990a28af5f34ea6e5e66410e41558519ec6b6ff1efae7981c0ab31_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_fc87c41ec2ab8ea1d9473046e03f118136f28dcd5f2deb86ee3f07b2d8803012 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fc87c41ec2ab8ea1d9473046e03f118136f28dcd5f2deb86ee3f07b2d8803012->enter($__internal_fc87c41ec2ab8ea1d9473046e03f118136f28dcd5f2deb86ee3f07b2d8803012_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_1e550e44b270e49a6f6c0c0517965e6fe62c3e6f665c986896fd37fae079e19f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e550e44b270e49a6f6c0c0517965e6fe62c3e6f665c986896fd37fae079e19f->enter($__internal_1e550e44b270e49a6f6c0c0517965e6fe62c3e6f665c986896fd37fae079e19f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_1e550e44b270e49a6f6c0c0517965e6fe62c3e6f665c986896fd37fae079e19f->leave($__internal_1e550e44b270e49a6f6c0c0517965e6fe62c3e6f665c986896fd37fae079e19f_prof);

        
        $__internal_fc87c41ec2ab8ea1d9473046e03f118136f28dcd5f2deb86ee3f07b2d8803012->leave($__internal_fc87c41ec2ab8ea1d9473046e03f118136f28dcd5f2deb86ee3f07b2d8803012_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_7c2571f34ab1041dfac04e3a1ac77276afd5d403b243603de194c413950b97b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7c2571f34ab1041dfac04e3a1ac77276afd5d403b243603de194c413950b97b0->enter($__internal_7c2571f34ab1041dfac04e3a1ac77276afd5d403b243603de194c413950b97b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c924b9322c6bb276fd26a7e29f93dbf82107ffde21bdfdbeb6c6449f524b6fb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c924b9322c6bb276fd26a7e29f93dbf82107ffde21bdfdbeb6c6449f524b6fb2->enter($__internal_c924b9322c6bb276fd26a7e29f93dbf82107ffde21bdfdbeb6c6449f524b6fb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_c924b9322c6bb276fd26a7e29f93dbf82107ffde21bdfdbeb6c6449f524b6fb2->leave($__internal_c924b9322c6bb276fd26a7e29f93dbf82107ffde21bdfdbeb6c6449f524b6fb2_prof);

        
        $__internal_7c2571f34ab1041dfac04e3a1ac77276afd5d403b243603de194c413950b97b0->leave($__internal_7c2571f34ab1041dfac04e3a1ac77276afd5d403b243603de194c413950b97b0_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "WebProfilerBundle:Collector:exception.html.twig", "C:\\Users\\pvrx043\\Documents\\perso\\projects\\financemanager\\financemanagersymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
