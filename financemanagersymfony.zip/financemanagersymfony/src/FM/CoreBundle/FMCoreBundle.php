<?php

namespace FM\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FMCoreBundle extends Bundle
{
}
